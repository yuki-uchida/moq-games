/* @ts-self-types="./moqt_client_wasm.d.ts" */

/**
 * The range is already resolved against the Largest Location this client
 * has sent: the end is the End Location its FETCH_OK carries (draft-14
 * §9.17), i.e. the Location after the last Object to send, where Object 0
 * covers the whole Group.
 */
export class FetchMessage {
    static __wrap(ptr) {
        const obj = Object.create(FetchMessage.prototype);
        obj.__wbg_ptr = ptr;
        FetchMessageFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        FetchMessageFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_fetchmessage_free(ptr, 0);
    }
    /**
     * @returns {bigint}
     */
    get endGroupId() {
        const ret = wasm.__wbg_get_fetchmessage_endGroupId(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
    /**
     * @returns {bigint}
     */
    get endObjectId() {
        const ret = wasm.__wbg_get_fetchmessage_endObjectId(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
    /**
     * @returns {number}
     */
    get groupOrder() {
        const ret = wasm.__wbg_get_fetchmessage_groupOrder(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {bigint}
     */
    get requestId() {
        const ret = wasm.__wbg_get_fetchmessage_requestId(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
    /**
     * @returns {bigint}
     */
    get startGroupId() {
        const ret = wasm.__wbg_get_fetchmessage_startGroupId(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
    /**
     * @returns {bigint}
     */
    get startObjectId() {
        const ret = wasm.__wbg_get_fetchmessage_startObjectId(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
    /**
     * @returns {string}
     */
    get trackName() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.__wbg_get_fetchmessage_trackName(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @returns {string[]}
     */
    get trackNamespace() {
        const ret = wasm.__wbg_get_fetchmessage_trackNamespace(this.__wbg_ptr);
        var v1 = getArrayJsValueFromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * @param {bigint} arg0
     */
    set endGroupId(arg0) {
        wasm.__wbg_set_fetchmessage_endGroupId(this.__wbg_ptr, arg0);
    }
    /**
     * @param {bigint} arg0
     */
    set endObjectId(arg0) {
        wasm.__wbg_set_fetchmessage_endObjectId(this.__wbg_ptr, arg0);
    }
    /**
     * @param {number} arg0
     */
    set groupOrder(arg0) {
        wasm.__wbg_set_fetchmessage_groupOrder(this.__wbg_ptr, arg0);
    }
    /**
     * @param {bigint} arg0
     */
    set requestId(arg0) {
        wasm.__wbg_set_fetchmessage_requestId(this.__wbg_ptr, arg0);
    }
    /**
     * @param {bigint} arg0
     */
    set startGroupId(arg0) {
        wasm.__wbg_set_fetchmessage_startGroupId(this.__wbg_ptr, arg0);
    }
    /**
     * @param {bigint} arg0
     */
    set startObjectId(arg0) {
        wasm.__wbg_set_fetchmessage_startObjectId(this.__wbg_ptr, arg0);
    }
    /**
     * @param {string} arg0
     */
    set trackName(arg0) {
        const ptr0 = passStringToWasm0(arg0, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        wasm.__wbg_set_fetchmessage_trackName(this.__wbg_ptr, ptr0, len0);
    }
    /**
     * @param {string[]} arg0
     */
    set trackNamespace(arg0) {
        const ptr0 = passArrayJsValueToWasm0(arg0, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        wasm.__wbg_set_fetchmessage_trackNamespace(this.__wbg_ptr, ptr0, len0);
    }
}
if (Symbol.dispose) FetchMessage.prototype[Symbol.dispose] = FetchMessage.prototype.free;

export class FetchObjectMessage {
    static __wrap(ptr) {
        const obj = Object.create(FetchObjectMessage.prototype);
        obj.__wbg_ptr = ptr;
        FetchObjectMessageFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        FetchObjectMessageFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_fetchobjectmessage_free(ptr, 0);
    }
    /**
     * @returns {bigint}
     */
    get groupId() {
        const ret = wasm.fetchobjectmessage_groupId(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
    /**
     * @returns {any}
     */
    get locHeader() {
        const ret = wasm.fetchobjectmessage_locHeader(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @returns {bigint}
     */
    get objectId() {
        const ret = wasm.fetchobjectmessage_objectId(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
    /**
     * @returns {Uint8Array}
     */
    get objectPayload() {
        const ret = wasm.fetchobjectmessage_objectPayload(this.__wbg_ptr);
        var v1 = getArrayU8FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        return v1;
    }
    /**
     * @returns {bigint}
     */
    get requestId() {
        const ret = wasm.fetchobjectmessage_requestId(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
}
if (Symbol.dispose) FetchObjectMessage.prototype[Symbol.dispose] = FetchObjectMessage.prototype.free;

export class FetchOkMessage {
    static __wrap(ptr) {
        const obj = Object.create(FetchOkMessage.prototype);
        obj.__wbg_ptr = ptr;
        FetchOkMessageFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        FetchOkMessageFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_fetchokmessage_free(ptr, 0);
    }
    /**
     * @returns {bigint}
     */
    get endGroupId() {
        const ret = wasm.fetchokmessage_endGroupId(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
    /**
     * @returns {bigint}
     */
    get endObjectId() {
        const ret = wasm.fetchokmessage_endObjectId(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
    /**
     * @returns {boolean}
     */
    get endOfTrack() {
        const ret = wasm.fetchokmessage_endOfTrack(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * @returns {bigint}
     */
    get requestId() {
        const ret = wasm.fetchokmessage_requestId(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
}
if (Symbol.dispose) FetchOkMessage.prototype[Symbol.dispose] = FetchOkMessage.prototype.free;

/**
 * How the relay ended a fetch stream: a FIN means every object up to the
 * FETCH_OK End Location has been delivered; a RESET_STREAM means objects may
 * be missing.
 */
export class FetchStreamEndMessage {
    static __wrap(ptr) {
        const obj = Object.create(FetchStreamEndMessage.prototype);
        obj.__wbg_ptr = ptr;
        FetchStreamEndMessageFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        FetchStreamEndMessageFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_fetchstreamendmessage_free(ptr, 0);
    }
    /**
     * @returns {boolean}
     */
    get isReset() {
        const ret = wasm.fetchstreamendmessage_isReset(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * @returns {bigint}
     */
    get requestId() {
        const ret = wasm.fetchstreamendmessage_requestId(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
    /**
     * @returns {bigint | undefined}
     */
    get resetErrorCode() {
        const ret = wasm.fetchstreamendmessage_resetErrorCode(this.__wbg_ptr);
        return ret[0] === 0 ? undefined : BigInt.asUintN(64, ret[1]);
    }
}
if (Symbol.dispose) FetchStreamEndMessage.prototype[Symbol.dispose] = FetchStreamEndMessage.prototype.free;

export class MOQTClient {
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        MOQTClientFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_moqtclient_free(ptr, 0);
    }
    /**
     * @returns {Promise<void>}
     */
    close() {
        const ret = wasm.moqtclient_close(this.__wbg_ptr);
        return ret;
    }
    /**
     * @param {bigint} request_id
     * @returns {Promise<void>}
     */
    finishFetch(request_id) {
        const ret = wasm.moqtclient_finishFetch(this.__wbg_ptr, request_id);
        return ret;
    }
    /**
     * @param {bigint} track_alias
     * @returns {SubgroupState}
     */
    getSubgroupState(track_alias) {
        const ret = wasm.moqtclient_getSubgroupState(this.__wbg_ptr, track_alias);
        return SubgroupState.__wrap(ret);
    }
    /**
     * @param {string[]} track_namespace
     * @param {string} track_name
     * @returns {BigUint64Array}
     */
    getTrackSubscribers(track_namespace, track_name) {
        const ptr0 = passArrayJsValueToWasm0(track_namespace, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(track_name, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.moqtclient_getTrackSubscribers(this.__wbg_ptr, ptr0, len0, ptr1, len1);
        var v3 = getArrayU64FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 8, 8);
        return v3;
    }
    /**
     * @param {bigint} track_alias
     */
    incrementSubgroupObject(track_alias) {
        wasm.moqtclient_incrementSubgroupObject(this.__wbg_ptr, track_alias);
    }
    /**
     * @returns {boolean}
     */
    isConnected() {
        const ret = wasm.moqtclient_isConnected(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * @param {bigint} request_id
     * @returns {boolean}
     */
    isSubscribed(request_id) {
        const ret = wasm.moqtclient_isSubscribed(this.__wbg_ptr, request_id);
        return ret !== 0;
    }
    /**
     * @param {bigint} track_alias
     */
    markSubgroupHeaderSent(track_alias) {
        wasm.moqtclient_markSubgroupHeaderSent(this.__wbg_ptr, track_alias);
    }
    /**
     * @param {string} url
     */
    constructor(url) {
        const ptr0 = passStringToWasm0(url, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.moqtclient_new(ptr0, len0);
        this.__wbg_ptr = ret;
        MOQTClientFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * @param {Function} callback
     */
    onConnectionClosed(callback) {
        wasm.moqtclient_onConnectionClosed(this.__wbg_ptr, callback);
    }
    /**
     * @param {Function} callback
     */
    onFetch(callback) {
        wasm.moqtclient_onFetch(this.__wbg_ptr, callback);
    }
    /**
     * @param {Function} callback
     */
    onFetchCancel(callback) {
        wasm.moqtclient_onFetchCancel(this.__wbg_ptr, callback);
    }
    /**
     * @param {Function} callback
     */
    onFetchObject(callback) {
        wasm.moqtclient_onFetchObject(this.__wbg_ptr, callback);
    }
    /**
     * @param {Function} callback
     */
    onFetchResponse(callback) {
        wasm.moqtclient_onFetchResponse(this.__wbg_ptr, callback);
    }
    /**
     * @param {Function} callback
     */
    onFetchStreamEnd(callback) {
        wasm.moqtclient_onFetchStreamEnd(this.__wbg_ptr, callback);
    }
    /**
     * @param {Function} callback
     */
    onIncomingUnsubscribe(callback) {
        wasm.moqtclient_onIncomingUnsubscribe(this.__wbg_ptr, callback);
    }
    /**
     * @param {Function} callback
     */
    onObjectDatagram(callback) {
        wasm.moqtclient_onObjectDatagram(this.__wbg_ptr, callback);
    }
    /**
     * @param {Function} callback
     */
    onObjectDatagramStatus(callback) {
        wasm.moqtclient_onObjectDatagramStatus(this.__wbg_ptr, callback);
    }
    /**
     * @param {Function} callback
     */
    onPublish(callback) {
        wasm.moqtclient_onPublish(this.__wbg_ptr, callback);
    }
    /**
     * @param {Function} callback
     */
    onPublishNamespace(callback) {
        wasm.moqtclient_onPublishNamespace(this.__wbg_ptr, callback);
    }
    /**
     * @param {Function} callback
     */
    onPublishNamespaceDone(callback) {
        wasm.moqtclient_onPublishNamespaceDone(this.__wbg_ptr, callback);
    }
    /**
     * @param {Function} callback
     */
    onPublishNamespaceResponse(callback) {
        wasm.moqtclient_onPublishNamespaceResponse(this.__wbg_ptr, callback);
    }
    /**
     * @param {Function} callback
     */
    onPublishResponse(callback) {
        wasm.moqtclient_onPublishResponse(this.__wbg_ptr, callback);
    }
    /**
     * @param {Function} callback
     */
    onServerSetup(callback) {
        wasm.moqtclient_onServerSetup(this.__wbg_ptr, callback);
    }
    /**
     * @param {Function} callback
     */
    onSubgroupHeader(callback) {
        wasm.moqtclient_onSubgroupHeader(this.__wbg_ptr, callback);
    }
    /**
     * @param {Function} callback
     */
    onSubgroupObject(callback) {
        wasm.moqtclient_onSubgroupObject(this.__wbg_ptr, callback);
    }
    /**
     * @param {Function} callback
     */
    onSubscribe(callback) {
        wasm.moqtclient_onSubscribe(this.__wbg_ptr, callback);
    }
    /**
     * @param {Function} callback
     */
    onSubscribeNamespaceResponse(callback) {
        wasm.moqtclient_onSubscribeNamespaceResponse(this.__wbg_ptr, callback);
    }
    /**
     * @param {Function} callback
     */
    onSubscribeResponse(callback) {
        wasm.moqtclient_onSubscribeResponse(this.__wbg_ptr, callback);
    }
    /**
     * @param {Function} callback
     */
    onTrackStatus(callback) {
        wasm.moqtclient_onTrackStatus(this.__wbg_ptr, callback);
    }
    /**
     * @param {Function} callback
     */
    onTrackStatusResponse(callback) {
        wasm.moqtclient_onTrackStatusResponse(this.__wbg_ptr, callback);
    }
    /**
     * @param {bigint} track_alias
     */
    resetSubgroupState(track_alias) {
        wasm.moqtclient_resetSubgroupState(this.__wbg_ptr, track_alias);
    }
    /**
     * @param {BigUint64Array} versions
     * @param {bigint} max_request_id
     * @param {string | null} [auth_token]
     * @returns {Promise<void>}
     */
    sendClientSetup(versions, max_request_id, auth_token) {
        const ptr0 = passArray64ToWasm0(versions, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        var ptr1 = isLikeNone(auth_token) ? 0 : passStringToWasm0(auth_token, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len1 = WASM_VECTOR_LEN;
        const ret = wasm.moqtclient_sendClientSetup(this.__wbg_ptr, ptr0, len0, max_request_id, ptr1, len1);
        return ret;
    }
    /**
     * @param {bigint} request_id
     * @param {string[]} track_namespace
     * @param {string} track_name
     * @param {bigint} start_group
     * @param {bigint} start_object
     * @param {bigint} end_group
     * @param {bigint} end_object
     * @param {number} group_order
     * @returns {Promise<void>}
     */
    sendFetch(request_id, track_namespace, track_name, start_group, start_object, end_group, end_object, group_order) {
        const ptr0 = passArrayJsValueToWasm0(track_namespace, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(track_name, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.moqtclient_sendFetch(this.__wbg_ptr, request_id, ptr0, len0, ptr1, len1, start_group, start_object, end_group, end_object, group_order);
        return ret;
    }
    /**
     * @param {bigint} request_id
     * @returns {Promise<void>}
     */
    sendFetchCancel(request_id) {
        const ret = wasm.moqtclient_sendFetchCancel(this.__wbg_ptr, request_id);
        return ret;
    }
    /**
     * @param {bigint} request_id
     * @param {bigint} error_code
     * @param {string} reason_phrase
     * @returns {Promise<void>}
     */
    sendFetchError(request_id, error_code, reason_phrase) {
        const ptr0 = passStringToWasm0(reason_phrase, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.moqtclient_sendFetchError(this.__wbg_ptr, request_id, error_code, ptr0, len0);
        return ret;
    }
    /**
     * @param {bigint} request_id
     * @param {bigint} group_id
     * @param {bigint} subgroup_id
     * @param {bigint} object_id
     * @param {number} publisher_priority
     * @param {number | null | undefined} object_status
     * @param {Uint8Array} object_payload
     * @param {any} loc_header
     * @returns {Promise<void>}
     */
    sendFetchObject(request_id, group_id, subgroup_id, object_id, publisher_priority, object_status, object_payload, loc_header) {
        const ptr0 = passArray8ToWasm0(object_payload, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.moqtclient_sendFetchObject(this.__wbg_ptr, request_id, group_id, subgroup_id, object_id, publisher_priority, isLikeNone(object_status) ? 0xFFFFFF : object_status, ptr0, len0, loc_header);
        return ret;
    }
    /**
     * @param {bigint} request_id
     * @returns {Promise<void>}
     */
    sendFetchOk(request_id) {
        const ret = wasm.moqtclient_sendFetchOk(this.__wbg_ptr, request_id);
        return ret;
    }
    /**
     * @param {string} new_session_uri
     * @returns {Promise<void>}
     */
    sendGoAway(new_session_uri) {
        const ptr0 = passStringToWasm0(new_session_uri, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.moqtclient_sendGoAway(this.__wbg_ptr, ptr0, len0);
        return ret;
    }
    /**
     * @param {bigint} request_id
     * @returns {Promise<void>}
     */
    sendMaxRequestId(request_id) {
        const ret = wasm.moqtclient_sendMaxRequestId(this.__wbg_ptr, request_id);
        return ret;
    }
    /**
     * @param {bigint} track_alias
     * @param {bigint} group_id
     * @param {bigint} object_id
     * @param {number} publisher_priority
     * @param {Uint8Array} object_payload
     * @param {any} loc_header
     * @returns {Promise<void>}
     */
    sendObjectDatagram(track_alias, group_id, object_id, publisher_priority, object_payload, loc_header) {
        const ptr0 = passArray8ToWasm0(object_payload, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.moqtclient_sendObjectDatagram(this.__wbg_ptr, track_alias, group_id, object_id, publisher_priority, ptr0, len0, loc_header);
        return ret;
    }
    /**
     * @param {bigint} track_alias
     * @param {bigint} group_id
     * @param {bigint} object_id
     * @param {number} publisher_priority
     * @param {number} object_status
     * @param {any} loc_header
     * @returns {Promise<void>}
     */
    sendObjectDatagramStatus(track_alias, group_id, object_id, publisher_priority, object_status, loc_header) {
        const ret = wasm.moqtclient_sendObjectDatagramStatus(this.__wbg_ptr, track_alias, group_id, object_id, publisher_priority, object_status, loc_header);
        return ret;
    }
    /**
     * @param {bigint} request_id
     * @param {string[]} track_namespace
     * @param {string} track_name
     * @param {bigint | null | undefined} track_alias
     * @param {number} group_order
     * @param {boolean} content_exists
     * @param {bigint | null | undefined} largest_group_id
     * @param {bigint | null | undefined} largest_object_id
     * @param {boolean} forward
     * @param {string} auth_info
     * @returns {Promise<bigint>}
     */
    sendPublish(request_id, track_namespace, track_name, track_alias, group_order, content_exists, largest_group_id, largest_object_id, forward, auth_info) {
        const ptr0 = passArrayJsValueToWasm0(track_namespace, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(track_name, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ptr2 = passStringToWasm0(auth_info, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len2 = WASM_VECTOR_LEN;
        const ret = wasm.moqtclient_sendPublish(this.__wbg_ptr, request_id, ptr0, len0, ptr1, len1, !isLikeNone(track_alias), isLikeNone(track_alias) ? BigInt(0) : track_alias, group_order, content_exists, !isLikeNone(largest_group_id), isLikeNone(largest_group_id) ? BigInt(0) : largest_group_id, !isLikeNone(largest_object_id), isLikeNone(largest_object_id) ? BigInt(0) : largest_object_id, forward, ptr2, len2);
        return ret;
    }
    /**
     * @param {bigint} request_id
     * @param {bigint} status_code
     * @param {bigint} stream_count
     * @param {string} error_reason
     * @returns {Promise<void>}
     */
    sendPublishDone(request_id, status_code, stream_count, error_reason) {
        const ptr0 = passStringToWasm0(error_reason, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.moqtclient_sendPublishDone(this.__wbg_ptr, request_id, status_code, stream_count, ptr0, len0);
        return ret;
    }
    /**
     * @param {bigint} request_id
     * @param {bigint} error_code
     * @param {string} reason_phrase
     * @returns {Promise<void>}
     */
    sendPublishError(request_id, error_code, reason_phrase) {
        const ptr0 = passStringToWasm0(reason_phrase, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.moqtclient_sendPublishError(this.__wbg_ptr, request_id, error_code, ptr0, len0);
        return ret;
    }
    /**
     * @param {bigint} request_id
     * @param {string[]} track_namespace
     * @param {string} auth_info
     * @returns {Promise<void>}
     */
    sendPublishNamespace(request_id, track_namespace, auth_info) {
        const ptr0 = passArrayJsValueToWasm0(track_namespace, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(auth_info, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.moqtclient_sendPublishNamespace(this.__wbg_ptr, request_id, ptr0, len0, ptr1, len1);
        return ret;
    }
    /**
     * @param {string[]} track_namespace
     * @param {bigint} error_code
     * @param {string} error_reason
     * @returns {Promise<void>}
     */
    sendPublishNamespaceCancel(track_namespace, error_code, error_reason) {
        const ptr0 = passArrayJsValueToWasm0(track_namespace, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(error_reason, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.moqtclient_sendPublishNamespaceCancel(this.__wbg_ptr, ptr0, len0, error_code, ptr1, len1);
        return ret;
    }
    /**
     * @param {string[]} track_namespace
     * @returns {Promise<void>}
     */
    sendPublishNamespaceDone(track_namespace) {
        const ptr0 = passArrayJsValueToWasm0(track_namespace, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.moqtclient_sendPublishNamespaceDone(this.__wbg_ptr, ptr0, len0);
        return ret;
    }
    /**
     * @param {bigint} request_id
     * @param {bigint} error_code
     * @param {string} reason_phrase
     * @returns {Promise<void>}
     */
    sendPublishNamespaceError(request_id, error_code, reason_phrase) {
        const ptr0 = passStringToWasm0(reason_phrase, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.moqtclient_sendPublishNamespaceError(this.__wbg_ptr, request_id, error_code, ptr0, len0);
        return ret;
    }
    /**
     * @param {bigint} request_id
     * @returns {Promise<void>}
     */
    sendPublishNamespaceOk(request_id) {
        const ret = wasm.moqtclient_sendPublishNamespaceOk(this.__wbg_ptr, request_id);
        return ret;
    }
    /**
     * @param {bigint} request_id
     * @param {number} subscriber_priority
     * @param {number} group_order
     * @param {number} filter_type
     * @param {bigint | null | undefined} start_group
     * @param {bigint | null | undefined} start_object
     * @param {bigint | null | undefined} end_group
     * @param {bigint | null | undefined} delivery_timeout
     * @param {boolean} forward
     * @returns {Promise<void>}
     */
    sendPublishOk(request_id, subscriber_priority, group_order, filter_type, start_group, start_object, end_group, delivery_timeout, forward) {
        const ret = wasm.moqtclient_sendPublishOk(this.__wbg_ptr, request_id, subscriber_priority, group_order, filter_type, !isLikeNone(start_group), isLikeNone(start_group) ? BigInt(0) : start_group, !isLikeNone(start_object), isLikeNone(start_object) ? BigInt(0) : start_object, !isLikeNone(end_group), isLikeNone(end_group) ? BigInt(0) : end_group, !isLikeNone(delivery_timeout), isLikeNone(delivery_timeout) ? BigInt(0) : delivery_timeout, forward);
        return ret;
    }
    /**
     * @param {bigint} request_id
     * @param {bigint} joining_request_id
     * @param {bigint} joining_start
     * @param {number} group_order
     * @returns {Promise<void>}
     */
    sendRelativeJoiningFetch(request_id, joining_request_id, joining_start, group_order) {
        const ret = wasm.moqtclient_sendRelativeJoiningFetch(this.__wbg_ptr, request_id, joining_request_id, joining_start, group_order);
        return ret;
    }
    /**
     * @param {bigint} maximum_request_id
     * @returns {Promise<void>}
     */
    sendRequestsBlocked(maximum_request_id) {
        const ret = wasm.moqtclient_sendRequestsBlocked(this.__wbg_ptr, maximum_request_id);
        return ret;
    }
    /**
     * @param {bigint} track_alias
     * @param {bigint} group_id
     * @param {bigint} subgroup_id
     * @param {number} publisher_priority
     * @returns {Promise<void>}
     */
    sendSubgroupHeader(track_alias, group_id, subgroup_id, publisher_priority) {
        const ret = wasm.moqtclient_sendSubgroupHeader(this.__wbg_ptr, track_alias, group_id, subgroup_id, publisher_priority);
        return ret;
    }
    /**
     * @param {bigint} track_alias
     * @param {bigint} group_id
     * @param {bigint} subgroup_id
     * @param {bigint} object_number
     * @param {number | null | undefined} object_status
     * @param {Uint8Array} object_payload
     * @param {any} loc_header
     * @returns {Promise<void>}
     */
    sendSubgroupObject(track_alias, group_id, subgroup_id, object_number, object_status, object_payload, loc_header) {
        const ptr0 = passArray8ToWasm0(object_payload, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.moqtclient_sendSubgroupObject(this.__wbg_ptr, track_alias, group_id, subgroup_id, object_number, isLikeNone(object_status) ? 0xFFFFFF : object_status, ptr0, len0, loc_header);
        return ret;
    }
    /**
     * @param {bigint} request_id
     * @param {string[]} track_namespace
     * @param {string} track_name
     * @param {number} subscriber_priority
     * @param {number} group_order
     * @param {number} filter_type
     * @param {bigint | null | undefined} start_group
     * @param {bigint | null | undefined} start_object
     * @param {bigint | null | undefined} end_group
     * @param {string} auth_info
     * @param {boolean} forward
     * @param {bigint | null} [delivery_timeout]
     * @returns {Promise<void>}
     */
    sendSubscribe(request_id, track_namespace, track_name, subscriber_priority, group_order, filter_type, start_group, start_object, end_group, auth_info, forward, delivery_timeout) {
        const ptr0 = passArrayJsValueToWasm0(track_namespace, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(track_name, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ptr2 = passStringToWasm0(auth_info, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len2 = WASM_VECTOR_LEN;
        const ret = wasm.moqtclient_sendSubscribe(this.__wbg_ptr, request_id, ptr0, len0, ptr1, len1, subscriber_priority, group_order, filter_type, !isLikeNone(start_group), isLikeNone(start_group) ? BigInt(0) : start_group, !isLikeNone(start_object), isLikeNone(start_object) ? BigInt(0) : start_object, !isLikeNone(end_group), isLikeNone(end_group) ? BigInt(0) : end_group, ptr2, len2, forward, !isLikeNone(delivery_timeout), isLikeNone(delivery_timeout) ? BigInt(0) : delivery_timeout);
        return ret;
    }
    /**
     * @param {bigint} request_id
     * @param {bigint} error_code
     * @param {string} reason_phrase
     * @returns {Promise<void>}
     */
    sendSubscribeError(request_id, error_code, reason_phrase) {
        const ptr0 = passStringToWasm0(reason_phrase, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.moqtclient_sendSubscribeError(this.__wbg_ptr, request_id, error_code, ptr0, len0);
        return ret;
    }
    /**
     * @param {bigint} request_id
     * @param {bigint} subscription_request_id
     * @param {boolean} forward
     * @returns {Promise<void>}
     */
    sendSubscribeForward(request_id, subscription_request_id, forward) {
        const ret = wasm.moqtclient_sendSubscribeForward(this.__wbg_ptr, request_id, subscription_request_id, forward);
        return ret;
    }
    /**
     * @param {bigint} request_id
     * @param {string[]} track_namespace_prefix
     * @param {string} auth_info
     * @returns {Promise<void>}
     */
    sendSubscribeNamespace(request_id, track_namespace_prefix, auth_info) {
        const ptr0 = passArrayJsValueToWasm0(track_namespace_prefix, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(auth_info, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.moqtclient_sendSubscribeNamespace(this.__wbg_ptr, request_id, ptr0, len0, ptr1, len1);
        return ret;
    }
    /**
     * @param {bigint} request_id
     * @param {bigint} expires
     * @param {bigint | null} [delivery_timeout]
     * @param {bigint | null} [max_duration]
     * @returns {Promise<bigint>}
     */
    sendSubscribeOk(request_id, expires, delivery_timeout, max_duration) {
        const ret = wasm.moqtclient_sendSubscribeOk(this.__wbg_ptr, request_id, expires, !isLikeNone(delivery_timeout), isLikeNone(delivery_timeout) ? BigInt(0) : delivery_timeout, !isLikeNone(max_duration), isLikeNone(max_duration) ? BigInt(0) : max_duration);
        return ret;
    }
    /**
     * @param {bigint} request_id
     * @param {bigint} subscription_request_id
     * @param {bigint} start_group
     * @param {bigint} start_object
     * @param {bigint} end_group
     * @param {number} subscriber_priority
     * @param {boolean} forward
     * @returns {Promise<void>}
     */
    sendSubscribeUpdate(request_id, subscription_request_id, start_group, start_object, end_group, subscriber_priority, forward) {
        const ret = wasm.moqtclient_sendSubscribeUpdate(this.__wbg_ptr, request_id, subscription_request_id, start_group, start_object, end_group, subscriber_priority, forward);
        return ret;
    }
    /**
     * @param {bigint} request_id
     * @param {string[]} track_namespace
     * @param {string} track_name
     * @param {string} auth_info
     * @returns {Promise<void>}
     */
    sendTrackStatus(request_id, track_namespace, track_name, auth_info) {
        const ptr0 = passArrayJsValueToWasm0(track_namespace, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(track_name, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ptr2 = passStringToWasm0(auth_info, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len2 = WASM_VECTOR_LEN;
        const ret = wasm.moqtclient_sendTrackStatus(this.__wbg_ptr, request_id, ptr0, len0, ptr1, len1, ptr2, len2);
        return ret;
    }
    /**
     * @param {bigint} request_id
     * @param {bigint} error_code
     * @param {string} reason_phrase
     * @returns {Promise<void>}
     */
    sendTrackStatusError(request_id, error_code, reason_phrase) {
        const ptr0 = passStringToWasm0(reason_phrase, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.moqtclient_sendTrackStatusError(this.__wbg_ptr, request_id, error_code, ptr0, len0);
        return ret;
    }
    /**
     * @param {bigint} request_id
     * @returns {Promise<void>}
     */
    sendTrackStatusOk(request_id) {
        const ret = wasm.moqtclient_sendTrackStatusOk(this.__wbg_ptr, request_id);
        return ret;
    }
    /**
     * @param {bigint} request_id
     * @returns {Promise<void>}
     */
    sendUnsubscribe(request_id) {
        const ret = wasm.moqtclient_sendUnsubscribe(this.__wbg_ptr, request_id);
        return ret;
    }
    /**
     * @param {string[]} track_namespace_prefix
     * @returns {Promise<void>}
     */
    sendUnsubscribeNamespace(track_namespace_prefix) {
        const ptr0 = passArrayJsValueToWasm0(track_namespace_prefix, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.moqtclient_sendUnsubscribeNamespace(this.__wbg_ptr, ptr0, len0);
        return ret;
    }
    /**
     * @returns {Promise<void>}
     */
    start() {
        const ret = wasm.moqtclient_start(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {any}
     */
    url() {
        const ret = wasm.moqtclient_url(this.__wbg_ptr);
        return ret;
    }
}
if (Symbol.dispose) MOQTClient.prototype[Symbol.dispose] = MOQTClient.prototype.free;

export class Mp4AudioTrack {
    static __wrap(ptr) {
        const obj = Object.create(Mp4AudioTrack.prototype);
        obj.__wbg_ptr = ptr;
        Mp4AudioTrackFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        Mp4AudioTrackFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_mp4audiotrack_free(ptr, 0);
    }
    /**
     * @returns {Uint8Array | undefined}
     */
    get audioSpecificConfig() {
        const ret = wasm.__wbg_get_mp4audiotrack_audioSpecificConfig(this.__wbg_ptr);
        let v1;
        if (ret[0] !== 0) {
            v1 = getArrayU8FromWasm0(ret[0], ret[1]).slice();
            wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        }
        return v1;
    }
    /**
     * @returns {number}
     */
    get channels() {
        const ret = wasm.__wbg_get_mp4audiotrack_channels(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {string}
     */
    get codec() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.__wbg_get_mp4audiotrack_codec(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @returns {number}
     */
    get sampleRate() {
        const ret = wasm.__wbg_get_mp4audiotrack_sampleRate(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * @param {Uint8Array | null} [arg0]
     */
    set audioSpecificConfig(arg0) {
        var ptr0 = isLikeNone(arg0) ? 0 : passArray8ToWasm0(arg0, wasm.__wbindgen_malloc);
        var len0 = WASM_VECTOR_LEN;
        wasm.__wbg_set_mp4audiotrack_audioSpecificConfig(this.__wbg_ptr, ptr0, len0);
    }
    /**
     * @param {number} arg0
     */
    set channels(arg0) {
        wasm.__wbg_set_mp4audiotrack_channels(this.__wbg_ptr, arg0);
    }
    /**
     * @param {string} arg0
     */
    set codec(arg0) {
        const ptr0 = passStringToWasm0(arg0, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        wasm.__wbg_set_mp4audiotrack_codec(this.__wbg_ptr, ptr0, len0);
    }
    /**
     * @param {number} arg0
     */
    set sampleRate(arg0) {
        wasm.__wbg_set_mp4audiotrack_sampleRate(this.__wbg_ptr, arg0);
    }
}
if (Symbol.dispose) Mp4AudioTrack.prototype[Symbol.dispose] = Mp4AudioTrack.prototype.free;

/**
 * Indexes a progressive MP4 from its `moov` atom, so a page can read the
 * samples of a large file from a `Blob` range by range instead of loading
 * the whole file into wasm memory.
 */
export class Mp4Index {
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        Mp4IndexFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_mp4index_free(ptr, 0);
    }
    /**
     * @param {Uint8Array} avcc
     * @param {boolean} sync
     * @returns {Uint8Array}
     */
    annexBVideoSample(avcc, sync) {
        const ptr0 = passArray8ToWasm0(avcc, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.mp4index_annexBVideoSample(this.__wbg_ptr, ptr0, len0, sync);
        if (ret[3]) {
            throw takeFromExternrefTable0(ret[2]);
        }
        var v2 = getArrayU8FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        return v2;
    }
    /**
     * @returns {Mp4AudioTrack | undefined}
     */
    audio() {
        const ret = wasm.mp4index_audio(this.__wbg_ptr);
        return ret === 0 ? undefined : Mp4AudioTrack.__wrap(ret);
    }
    /**
     * @returns {number}
     */
    durationMicros() {
        const ret = wasm.mp4index_durationMicros(this.__wbg_ptr);
        return ret;
    }
    /**
     * @param {Uint8Array} moov
     */
    constructor(moov) {
        const ptr0 = passArray8ToWasm0(moov, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.mp4index_new(ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        this.__wbg_ptr = ret[0];
        Mp4IndexFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * @returns {number}
     */
    reorderDelayMicros() {
        const ret = wasm.mp4index_reorderDelayMicros(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {Mp4SampleTable}
     */
    samples() {
        const ret = wasm.mp4index_samples(this.__wbg_ptr);
        return Mp4SampleTable.__wrap(ret);
    }
    /**
     * @returns {Mp4VideoTrack | undefined}
     */
    video() {
        const ret = wasm.mp4index_video(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return ret[0] === 0 ? undefined : Mp4VideoTrack.__wrap(ret[0]);
    }
}
if (Symbol.dispose) Mp4Index.prototype[Symbol.dispose] = Mp4Index.prototype.free;

/**
 * The sample table as parallel columns, one entry per sample in decode
 * order: `kind` is 0 for video and 1 for audio, `sync` is 1 for a keyframe.
 */
export class Mp4SampleTable {
    static __wrap(ptr) {
        const obj = Object.create(Mp4SampleTable.prototype);
        obj.__wbg_ptr = ptr;
        Mp4SampleTableFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        Mp4SampleTableFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_mp4sampletable_free(ptr, 0);
    }
    /**
     * @returns {Float64Array}
     */
    get dtsMicros() {
        const ret = wasm.__wbg_get_mp4sampletable_dtsMicros(this.__wbg_ptr);
        var v1 = getArrayF64FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 8, 8);
        return v1;
    }
    /**
     * @returns {Uint8Array}
     */
    get kind() {
        const ret = wasm.__wbg_get_mp4sampletable_kind(this.__wbg_ptr);
        var v1 = getArrayU8FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        return v1;
    }
    /**
     * @returns {Float64Array}
     */
    get offset() {
        const ret = wasm.__wbg_get_mp4sampletable_offset(this.__wbg_ptr);
        var v1 = getArrayF64FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 8, 8);
        return v1;
    }
    /**
     * @returns {Float64Array}
     */
    get ptsMicros() {
        const ret = wasm.__wbg_get_mp4sampletable_ptsMicros(this.__wbg_ptr);
        var v1 = getArrayF64FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 8, 8);
        return v1;
    }
    /**
     * @returns {Uint32Array}
     */
    get size() {
        const ret = wasm.__wbg_get_mp4sampletable_size(this.__wbg_ptr);
        var v1 = getArrayU32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * @returns {Uint8Array}
     */
    get sync() {
        const ret = wasm.__wbg_get_mp4sampletable_sync(this.__wbg_ptr);
        var v1 = getArrayU8FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        return v1;
    }
    /**
     * @param {Float64Array} arg0
     */
    set dtsMicros(arg0) {
        const ptr0 = passArrayF64ToWasm0(arg0, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        wasm.__wbg_set_mp4sampletable_dtsMicros(this.__wbg_ptr, ptr0, len0);
    }
    /**
     * @param {Uint8Array} arg0
     */
    set kind(arg0) {
        const ptr0 = passArray8ToWasm0(arg0, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        wasm.__wbg_set_mp4sampletable_kind(this.__wbg_ptr, ptr0, len0);
    }
    /**
     * @param {Float64Array} arg0
     */
    set offset(arg0) {
        const ptr0 = passArrayF64ToWasm0(arg0, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        wasm.__wbg_set_mp4sampletable_offset(this.__wbg_ptr, ptr0, len0);
    }
    /**
     * @param {Float64Array} arg0
     */
    set ptsMicros(arg0) {
        const ptr0 = passArrayF64ToWasm0(arg0, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        wasm.__wbg_set_mp4sampletable_ptsMicros(this.__wbg_ptr, ptr0, len0);
    }
    /**
     * @param {Uint32Array} arg0
     */
    set size(arg0) {
        const ptr0 = passArray32ToWasm0(arg0, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        wasm.__wbg_set_mp4sampletable_size(this.__wbg_ptr, ptr0, len0);
    }
    /**
     * @param {Uint8Array} arg0
     */
    set sync(arg0) {
        const ptr0 = passArray8ToWasm0(arg0, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        wasm.__wbg_set_mp4sampletable_sync(this.__wbg_ptr, ptr0, len0);
    }
}
if (Symbol.dispose) Mp4SampleTable.prototype[Symbol.dispose] = Mp4SampleTable.prototype.free;

export class Mp4VideoTrack {
    static __wrap(ptr) {
        const obj = Object.create(Mp4VideoTrack.prototype);
        obj.__wbg_ptr = ptr;
        Mp4VideoTrackFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        Mp4VideoTrackFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_mp4videotrack_free(ptr, 0);
    }
    /**
     * @returns {string}
     */
    get codec() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.__wbg_get_mp4videotrack_codec(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @returns {number}
     */
    get height() {
        const ret = wasm.__wbg_get_mp4videotrack_height(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * @returns {number}
     */
    get width() {
        const ret = wasm.__wbg_get_mp4videotrack_width(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * @param {string} arg0
     */
    set codec(arg0) {
        const ptr0 = passStringToWasm0(arg0, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        wasm.__wbg_set_mp4videotrack_codec(this.__wbg_ptr, ptr0, len0);
    }
    /**
     * @param {number} arg0
     */
    set height(arg0) {
        wasm.__wbg_set_mp4videotrack_height(this.__wbg_ptr, arg0);
    }
    /**
     * @param {number} arg0
     */
    set width(arg0) {
        wasm.__wbg_set_mp4videotrack_width(this.__wbg_ptr, arg0);
    }
}
if (Symbol.dispose) Mp4VideoTrack.prototype[Symbol.dispose] = Mp4VideoTrack.prototype.free;

export class NamespaceOkMessage {
    static __wrap(ptr) {
        const obj = Object.create(NamespaceOkMessage.prototype);
        obj.__wbg_ptr = ptr;
        NamespaceOkMessageFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        NamespaceOkMessageFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_namespaceokmessage_free(ptr, 0);
    }
    /**
     * @returns {bigint}
     */
    get requestId() {
        const ret = wasm.namespaceokmessage_requestId(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
}
if (Symbol.dispose) NamespaceOkMessage.prototype[Symbol.dispose] = NamespaceOkMessage.prototype.free;

export class ObjectDatagramMessage {
    static __wrap(ptr) {
        const obj = Object.create(ObjectDatagramMessage.prototype);
        obj.__wbg_ptr = ptr;
        ObjectDatagramMessageFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        ObjectDatagramMessageFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_objectdatagrammessage_free(ptr, 0);
    }
    /**
     * @returns {bigint}
     */
    get groupId() {
        const ret = wasm.objectdatagrammessage_groupId(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
    /**
     * @returns {any}
     */
    get locHeader() {
        const ret = wasm.objectdatagrammessage_locHeader(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @returns {bigint | undefined}
     */
    get objectId() {
        const ret = wasm.objectdatagrammessage_objectId(this.__wbg_ptr);
        return ret[0] === 0 ? undefined : BigInt.asUintN(64, ret[1]);
    }
    /**
     * @returns {Uint8Array}
     */
    get objectPayload() {
        const ret = wasm.objectdatagrammessage_objectPayload(this.__wbg_ptr);
        var v1 = getArrayU8FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        return v1;
    }
    /**
     * @returns {number}
     */
    get objectPayloadLength() {
        const ret = wasm.objectdatagrammessage_objectPayloadLength(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * @returns {number}
     */
    get publisherPriority() {
        const ret = wasm.objectdatagrammessage_publisherPriority(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {bigint}
     */
    get trackAlias() {
        const ret = wasm.objectdatagrammessage_trackAlias(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
}
if (Symbol.dispose) ObjectDatagramMessage.prototype[Symbol.dispose] = ObjectDatagramMessage.prototype.free;

export class ObjectDatagramStatusMessage {
    static __wrap(ptr) {
        const obj = Object.create(ObjectDatagramStatusMessage.prototype);
        obj.__wbg_ptr = ptr;
        ObjectDatagramStatusMessageFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        ObjectDatagramStatusMessageFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_objectdatagramstatusmessage_free(ptr, 0);
    }
    /**
     * @returns {bigint}
     */
    get groupId() {
        const ret = wasm.objectdatagramstatusmessage_groupId(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
    /**
     * @returns {any}
     */
    get locHeader() {
        const ret = wasm.objectdatagramstatusmessage_locHeader(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @returns {bigint | undefined}
     */
    get objectId() {
        const ret = wasm.objectdatagramstatusmessage_objectId(this.__wbg_ptr);
        return ret[0] === 0 ? undefined : BigInt.asUintN(64, ret[1]);
    }
    /**
     * @returns {number}
     */
    get objectStatus() {
        const ret = wasm.objectdatagramstatusmessage_objectStatus(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {number}
     */
    get publisherPriority() {
        const ret = wasm.objectdatagramstatusmessage_publisherPriority(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {bigint}
     */
    get trackAlias() {
        const ret = wasm.objectdatagramstatusmessage_trackAlias(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
}
if (Symbol.dispose) ObjectDatagramStatusMessage.prototype[Symbol.dispose] = ObjectDatagramStatusMessage.prototype.free;

export class PublishMessage {
    static __wrap(ptr) {
        const obj = Object.create(PublishMessage.prototype);
        obj.__wbg_ptr = ptr;
        PublishMessageFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        PublishMessageFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_publishmessage_free(ptr, 0);
    }
    /**
     * @returns {boolean}
     */
    get contentExists() {
        const ret = wasm.publishmessage_contentExists(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * @returns {boolean}
     */
    get forward() {
        const ret = wasm.publishmessage_forward(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * @returns {number}
     */
    get groupOrder() {
        const ret = wasm.publishmessage_groupOrder(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {bigint | undefined}
     */
    get largestGroupId() {
        const ret = wasm.publishmessage_largestGroupId(this.__wbg_ptr);
        return ret[0] === 0 ? undefined : BigInt.asUintN(64, ret[1]);
    }
    /**
     * @returns {bigint | undefined}
     */
    get largestObjectId() {
        const ret = wasm.publishmessage_largestObjectId(this.__wbg_ptr);
        return ret[0] === 0 ? undefined : BigInt.asUintN(64, ret[1]);
    }
    /**
     * @returns {bigint}
     */
    get requestId() {
        const ret = wasm.publishmessage_requestId(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
    /**
     * @returns {bigint}
     */
    get trackAlias() {
        const ret = wasm.publishmessage_trackAlias(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
    /**
     * @returns {string}
     */
    get trackName() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.publishmessage_trackName(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @returns {string[]}
     */
    get trackNamespace() {
        const ret = wasm.publishmessage_trackNamespace(this.__wbg_ptr);
        var v1 = getArrayJsValueFromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
}
if (Symbol.dispose) PublishMessage.prototype[Symbol.dispose] = PublishMessage.prototype.free;

export class PublishNamespaceDoneMessage {
    static __wrap(ptr) {
        const obj = Object.create(PublishNamespaceDoneMessage.prototype);
        obj.__wbg_ptr = ptr;
        PublishNamespaceDoneMessageFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        PublishNamespaceDoneMessageFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_publishnamespacedonemessage_free(ptr, 0);
    }
    /**
     * @returns {string[]}
     */
    get trackNamespace() {
        const ret = wasm.publishnamespacedonemessage_trackNamespace(this.__wbg_ptr);
        var v1 = getArrayJsValueFromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
}
if (Symbol.dispose) PublishNamespaceDoneMessage.prototype[Symbol.dispose] = PublishNamespaceDoneMessage.prototype.free;

export class PublishNamespaceMessage {
    static __wrap(ptr) {
        const obj = Object.create(PublishNamespaceMessage.prototype);
        obj.__wbg_ptr = ptr;
        PublishNamespaceMessageFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        PublishNamespaceMessageFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_publishnamespacemessage_free(ptr, 0);
    }
    /**
     * @returns {bigint}
     */
    get requestId() {
        const ret = wasm.publishnamespacemessage_requestId(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
    /**
     * @returns {string[]}
     */
    get trackNamespace() {
        const ret = wasm.publishnamespacemessage_trackNamespace(this.__wbg_ptr);
        var v1 = getArrayJsValueFromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
}
if (Symbol.dispose) PublishNamespaceMessage.prototype[Symbol.dispose] = PublishNamespaceMessage.prototype.free;

export class PublishOkMessage {
    static __wrap(ptr) {
        const obj = Object.create(PublishOkMessage.prototype);
        obj.__wbg_ptr = ptr;
        PublishOkMessageFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        PublishOkMessageFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_publishokmessage_free(ptr, 0);
    }
    /**
     * @returns {bigint | undefined}
     */
    get deliveryTimeout() {
        const ret = wasm.publishokmessage_deliveryTimeout(this.__wbg_ptr);
        return ret[0] === 0 ? undefined : BigInt.asUintN(64, ret[1]);
    }
    /**
     * @returns {bigint | undefined}
     */
    get endGroup() {
        const ret = wasm.publishokmessage_endGroup(this.__wbg_ptr);
        return ret[0] === 0 ? undefined : BigInt.asUintN(64, ret[1]);
    }
    /**
     * @returns {number}
     */
    get filterType() {
        const ret = wasm.publishokmessage_filterType(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {boolean}
     */
    get forward() {
        const ret = wasm.publishokmessage_forward(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * @returns {number}
     */
    get groupOrder() {
        const ret = wasm.publishokmessage_groupOrder(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {bigint}
     */
    get requestId() {
        const ret = wasm.publishokmessage_requestId(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
    /**
     * @returns {bigint | undefined}
     */
    get startGroup() {
        const ret = wasm.publishokmessage_startGroup(this.__wbg_ptr);
        return ret[0] === 0 ? undefined : BigInt.asUintN(64, ret[1]);
    }
    /**
     * @returns {bigint | undefined}
     */
    get startObject() {
        const ret = wasm.publishokmessage_startObject(this.__wbg_ptr);
        return ret[0] === 0 ? undefined : BigInt.asUintN(64, ret[1]);
    }
    /**
     * @returns {number}
     */
    get subscriberPriority() {
        const ret = wasm.publishokmessage_subscriberPriority(this.__wbg_ptr);
        return ret;
    }
}
if (Symbol.dispose) PublishOkMessage.prototype[Symbol.dispose] = PublishOkMessage.prototype.free;

export class RequestErrorMessage {
    static __wrap(ptr) {
        const obj = Object.create(RequestErrorMessage.prototype);
        obj.__wbg_ptr = ptr;
        RequestErrorMessageFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        RequestErrorMessageFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_requesterrormessage_free(ptr, 0);
    }
    /**
     * @returns {bigint}
     */
    get errorCode() {
        const ret = wasm.requesterrormessage_errorCode(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
    /**
     * @returns {string}
     */
    get reasonPhrase() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.requesterrormessage_reasonPhrase(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @returns {bigint}
     */
    get requestId() {
        const ret = wasm.requesterrormessage_requestId(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
}
if (Symbol.dispose) RequestErrorMessage.prototype[Symbol.dispose] = RequestErrorMessage.prototype.free;

export class ServerSetupMessage {
    static __wrap(ptr) {
        const obj = Object.create(ServerSetupMessage.prototype);
        obj.__wbg_ptr = ptr;
        ServerSetupMessageFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        ServerSetupMessageFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_serversetupmessage_free(ptr, 0);
    }
    /**
     * @returns {bigint}
     */
    get maxRequestId() {
        const ret = wasm.serversetupmessage_maxRequestId(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
    /**
     * @returns {number}
     */
    get version() {
        const ret = wasm.serversetupmessage_version(this.__wbg_ptr);
        return ret >>> 0;
    }
}
if (Symbol.dispose) ServerSetupMessage.prototype[Symbol.dispose] = ServerSetupMessage.prototype.free;

export class SubgroupHeaderMessage {
    static __wrap(ptr) {
        const obj = Object.create(SubgroupHeaderMessage.prototype);
        obj.__wbg_ptr = ptr;
        SubgroupHeaderMessageFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        SubgroupHeaderMessageFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_subgroupheadermessage_free(ptr, 0);
    }
    /**
     * @returns {bigint}
     */
    get groupId() {
        const ret = wasm.subgroupheadermessage_groupId(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
    /**
     * @returns {number}
     */
    get publisherPriority() {
        const ret = wasm.subgroupheadermessage_publisherPriority(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {bigint | undefined}
     */
    get subgroupId() {
        const ret = wasm.subgroupheadermessage_subgroupId(this.__wbg_ptr);
        return ret[0] === 0 ? undefined : BigInt.asUintN(64, ret[1]);
    }
    /**
     * @returns {bigint}
     */
    get trackAlias() {
        const ret = wasm.subgroupheadermessage_trackAlias(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
}
if (Symbol.dispose) SubgroupHeaderMessage.prototype[Symbol.dispose] = SubgroupHeaderMessage.prototype.free;

export class SubgroupObjectMessage {
    static __wrap(ptr) {
        const obj = Object.create(SubgroupObjectMessage.prototype);
        obj.__wbg_ptr = ptr;
        SubgroupObjectMessageFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        SubgroupObjectMessageFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_subgroupobjectmessage_free(ptr, 0);
    }
    /**
     * @returns {any}
     */
    get locHeader() {
        const ret = wasm.subgroupobjectmessage_locHeader(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @returns {bigint}
     */
    get objectId() {
        const ret = wasm.subgroupobjectmessage_objectId(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
    /**
     * @returns {bigint}
     */
    get objectIdDelta() {
        const ret = wasm.subgroupobjectmessage_objectIdDelta(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
    /**
     * @returns {Uint8Array}
     */
    get objectPayload() {
        const ret = wasm.subgroupobjectmessage_objectPayload(this.__wbg_ptr);
        var v1 = getArrayU8FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        return v1;
    }
    /**
     * @returns {number}
     */
    get objectPayloadLength() {
        const ret = wasm.subgroupobjectmessage_objectPayloadLength(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * @returns {number | undefined}
     */
    get objectStatus() {
        const ret = wasm.subgroupobjectmessage_objectStatus(this.__wbg_ptr);
        return ret === 0xFFFFFF ? undefined : ret;
    }
    /**
     * @returns {bigint | undefined}
     */
    get subgroupId() {
        const ret = wasm.subgroupobjectmessage_subgroupId(this.__wbg_ptr);
        return ret[0] === 0 ? undefined : BigInt.asUintN(64, ret[1]);
    }
}
if (Symbol.dispose) SubgroupObjectMessage.prototype[Symbol.dispose] = SubgroupObjectMessage.prototype.free;

/**
 * JavaScript-friendly wrapper for subgroup send state
 */
export class SubgroupState {
    static __wrap(ptr) {
        const obj = Object.create(SubgroupState.prototype);
        obj.__wbg_ptr = ptr;
        SubgroupStateFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        SubgroupStateFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_subgroupstate_free(ptr, 0);
    }
    /**
     * @returns {bigint}
     */
    get groupId() {
        const ret = wasm.subgroupstate_groupId(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
    /**
     * @returns {boolean}
     */
    get headerSent() {
        const ret = wasm.subgroupstate_headerSent(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * @returns {bigint}
     */
    get objectId() {
        const ret = wasm.subgroupstate_objectId(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
    /**
     * @returns {bigint}
     */
    get subgroupId() {
        const ret = wasm.subgroupstate_subgroupId(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
    /**
     * @returns {bigint}
     */
    get trackAlias() {
        const ret = wasm.subgroupstate_trackAlias(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
}
if (Symbol.dispose) SubgroupState.prototype[Symbol.dispose] = SubgroupState.prototype.free;

export class SubscribeMessage {
    static __wrap(ptr) {
        const obj = Object.create(SubscribeMessage.prototype);
        obj.__wbg_ptr = ptr;
        SubscribeMessageFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        SubscribeMessageFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_subscribemessage_free(ptr, 0);
    }
    /**
     * @returns {bigint | undefined}
     */
    get endGroup() {
        const ret = wasm.subscribemessage_endGroup(this.__wbg_ptr);
        return ret[0] === 0 ? undefined : BigInt.asUintN(64, ret[1]);
    }
    /**
     * @returns {number}
     */
    get filterType() {
        const ret = wasm.subscribemessage_filterType(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {boolean}
     */
    get forward() {
        const ret = wasm.subscribemessage_forward(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * @returns {number}
     */
    get groupOrder() {
        const ret = wasm.subscribemessage_groupOrder(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {bigint}
     */
    get requestId() {
        const ret = wasm.subscribemessage_requestId(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
    /**
     * @returns {bigint | undefined}
     */
    get startGroup() {
        const ret = wasm.subscribemessage_startGroup(this.__wbg_ptr);
        return ret[0] === 0 ? undefined : BigInt.asUintN(64, ret[1]);
    }
    /**
     * @returns {bigint | undefined}
     */
    get startObject() {
        const ret = wasm.subscribemessage_startObject(this.__wbg_ptr);
        return ret[0] === 0 ? undefined : BigInt.asUintN(64, ret[1]);
    }
    /**
     * @returns {number}
     */
    get subscriberPriority() {
        const ret = wasm.subscribemessage_subscriberPriority(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {string}
     */
    get trackName() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.subscribemessage_trackName(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @returns {string[]}
     */
    get trackNamespace() {
        const ret = wasm.subscribemessage_trackNamespace(this.__wbg_ptr);
        var v1 = getArrayJsValueFromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
}
if (Symbol.dispose) SubscribeMessage.prototype[Symbol.dispose] = SubscribeMessage.prototype.free;

export class SubscribeNamespaceMessage {
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        SubscribeNamespaceMessageFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_subscribenamespacemessage_free(ptr, 0);
    }
    /**
     * @returns {bigint}
     */
    get requestId() {
        const ret = wasm.subscribenamespacemessage_requestId(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
    /**
     * @returns {string[]}
     */
    get trackNamespacePrefix() {
        const ret = wasm.subscribenamespacemessage_trackNamespacePrefix(this.__wbg_ptr);
        var v1 = getArrayJsValueFromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
}
if (Symbol.dispose) SubscribeNamespaceMessage.prototype[Symbol.dispose] = SubscribeNamespaceMessage.prototype.free;

export class SubscribeOkMessage {
    static __wrap(ptr) {
        const obj = Object.create(SubscribeOkMessage.prototype);
        obj.__wbg_ptr = ptr;
        SubscribeOkMessageFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        SubscribeOkMessageFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_subscribeokmessage_free(ptr, 0);
    }
    /**
     * @returns {boolean}
     */
    get contentExists() {
        const ret = wasm.subscribeokmessage_contentExists(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * @returns {bigint | undefined}
     */
    get deliveryTimeout() {
        const ret = wasm.subscribeokmessage_deliveryTimeout(this.__wbg_ptr);
        return ret[0] === 0 ? undefined : BigInt.asUintN(64, ret[1]);
    }
    /**
     * @returns {bigint}
     */
    get expires() {
        const ret = wasm.subscribeokmessage_expires(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
    /**
     * @returns {number}
     */
    get groupOrder() {
        const ret = wasm.subscribeokmessage_groupOrder(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {bigint | undefined}
     */
    get largestGroupId() {
        const ret = wasm.subscribeokmessage_largestGroupId(this.__wbg_ptr);
        return ret[0] === 0 ? undefined : BigInt.asUintN(64, ret[1]);
    }
    /**
     * @returns {bigint | undefined}
     */
    get largestObjectId() {
        const ret = wasm.subscribeokmessage_largestObjectId(this.__wbg_ptr);
        return ret[0] === 0 ? undefined : BigInt.asUintN(64, ret[1]);
    }
    /**
     * @returns {bigint | undefined}
     */
    get maxDuration() {
        const ret = wasm.subscribeokmessage_maxDuration(this.__wbg_ptr);
        return ret[0] === 0 ? undefined : BigInt.asUintN(64, ret[1]);
    }
    /**
     * @returns {bigint}
     */
    get requestId() {
        const ret = wasm.subscribeokmessage_requestId(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
    /**
     * @returns {bigint}
     */
    get trackAlias() {
        const ret = wasm.subscribeokmessage_trackAlias(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
}
if (Symbol.dispose) SubscribeOkMessage.prototype[Symbol.dispose] = SubscribeOkMessage.prototype.free;

export function main() {
    wasm.main();
}

/**
 * @param {any} value
 * @returns {string}
 */
export function msf_catalog_to_json(value) {
    let deferred2_0;
    let deferred2_1;
    try {
        const ret = wasm.msf_catalog_to_json(value);
        var ptr1 = ret[0];
        var len1 = ret[1];
        if (ret[3]) {
            ptr1 = 0; len1 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred2_0 = ptr1;
        deferred2_1 = len1;
        return getStringFromWasm0(ptr1, len1);
    } finally {
        wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
    }
}

/**
 * @param {string} json
 * @returns {any}
 */
export function parse_msf_catalog_json(json) {
    const ptr0 = passStringToWasm0(json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.parse_msf_catalog_json(ptr0, len0);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}
function __wbg_get_imports() {
    const import0 = {
        __proto__: null,
        __wbg_Error_92b29b0548f8b746: function(arg0, arg1) {
            const ret = Error(getStringFromWasm0(arg0, arg1));
            return ret;
        },
        __wbg_Number_9a4e0ecb0fa16705: function(arg0) {
            const ret = Number(arg0);
            return ret;
        },
        __wbg_String_8564e559799eccda: function(arg0, arg1) {
            const ret = String(arg1);
            const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
            getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
        },
        __wbg___wbindgen_bigint_get_as_i64_d968e41184ae354f: function(arg0, arg1) {
            const v = arg1;
            const ret = typeof(v) === 'bigint' ? v : undefined;
            getDataViewMemory0().setBigInt64(arg0 + 8 * 1, isLikeNone(ret) ? BigInt(0) : ret, true);
            getDataViewMemory0().setInt32(arg0 + 4 * 0, !isLikeNone(ret), true);
        },
        __wbg___wbindgen_boolean_get_fa956cfa2d1bd751: function(arg0) {
            const v = arg0;
            const ret = typeof(v) === 'boolean' ? v : undefined;
            return isLikeNone(ret) ? 0xFFFFFF : ret ? 1 : 0;
        },
        __wbg___wbindgen_debug_string_c25d447a39f5578f: function(arg0, arg1) {
            const ret = debugString(arg1);
            const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
            getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
        },
        __wbg___wbindgen_in_aca499c5de7ff5e5: function(arg0, arg1) {
            const ret = arg0 in arg1;
            return ret;
        },
        __wbg___wbindgen_is_bigint_2f76dc55065b4273: function(arg0) {
            const ret = typeof(arg0) === 'bigint';
            return ret;
        },
        __wbg___wbindgen_is_function_1ff95bcc5517c252: function(arg0) {
            const ret = typeof(arg0) === 'function';
            return ret;
        },
        __wbg___wbindgen_is_null_ea9085d691f535d3: function(arg0) {
            const ret = arg0 === null;
            return ret;
        },
        __wbg___wbindgen_is_object_a27215656b807791: function(arg0) {
            const val = arg0;
            const ret = typeof(val) === 'object' && val !== null;
            return ret;
        },
        __wbg___wbindgen_is_string_ea5e6cc2e4141dfe: function(arg0) {
            const ret = typeof(arg0) === 'string';
            return ret;
        },
        __wbg___wbindgen_is_undefined_c05833b95a3cf397: function(arg0) {
            const ret = arg0 === undefined;
            return ret;
        },
        __wbg___wbindgen_jsval_eq_e659fcf7b0e32763: function(arg0, arg1) {
            const ret = arg0 === arg1;
            return ret;
        },
        __wbg___wbindgen_jsval_loose_eq_db4c3b15f63fc170: function(arg0, arg1) {
            const ret = arg0 == arg1;
            return ret;
        },
        __wbg___wbindgen_number_get_394265ed1e1b84ee: function(arg0, arg1) {
            const obj = arg1;
            const ret = typeof(obj) === 'number' ? obj : undefined;
            getDataViewMemory0().setFloat64(arg0 + 8 * 1, isLikeNone(ret) ? 0 : ret, true);
            getDataViewMemory0().setInt32(arg0 + 4 * 0, !isLikeNone(ret), true);
        },
        __wbg___wbindgen_string_get_b0ca35b86a603356: function(arg0, arg1) {
            const obj = arg1;
            const ret = typeof(obj) === 'string' ? obj : undefined;
            var ptr1 = isLikeNone(ret) ? 0 : passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            var len1 = WASM_VECTOR_LEN;
            getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
            getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
        },
        __wbg___wbindgen_throw_344f42d3211c4765: function(arg0, arg1) {
            throw new Error(getStringFromWasm0(arg0, arg1));
        },
        __wbg__wbg_cb_unref_fffb441def202758: function(arg0) {
            arg0._wbg_cb_unref();
        },
        __wbg_abort_962541bfa57985c4: function(arg0) {
            const ret = arg0.abort();
            return ret;
        },
        __wbg_call_44b7209e1e252e6a: function() { return handleError(function (arg0, arg1, arg2, arg3, arg4) {
            const ret = arg0.call(arg1, arg2, arg3, arg4);
            return ret;
        }, arguments); },
        __wbg_call_8a2dd23819f8a60a: function() { return handleError(function (arg0, arg1) {
            const ret = arg0.call(arg1);
            return ret;
        }, arguments); },
        __wbg_call_a6e5c5dce5018821: function() { return handleError(function (arg0, arg1, arg2) {
            const ret = arg0.call(arg1, arg2);
            return ret;
        }, arguments); },
        __wbg_cancel_3983a93e24cc66b3: function(arg0) {
            const ret = arg0.cancel();
            return ret;
        },
        __wbg_close_1e6096d41f7ce5d0: function(arg0) {
            const ret = arg0.close();
            return ret;
        },
        __wbg_close_9aa4d8117c23924b: function(arg0) {
            arg0.close();
        },
        __wbg_createBidirectionalStream_f9081daa37bad3ee: function(arg0) {
            const ret = arg0.createBidirectionalStream();
            return ret;
        },
        __wbg_createUnidirectionalStream_9ff0e4127f40ed0d: function(arg0) {
            const ret = arg0.createUnidirectionalStream();
            return ret;
        },
        __wbg_datagrams_d49e2847b8ba9363: function(arg0) {
            const ret = arg0.datagrams;
            return ret;
        },
        __wbg_done_89b2b13e91a60321: function(arg0) {
            const ret = arg0.done;
            return ret;
        },
        __wbg_entries_015dc610cd81ede0: function(arg0) {
            const ret = Object.entries(arg0);
            return ret;
        },
        __wbg_error_a6fa202b58aa1cd3: function(arg0, arg1) {
            let deferred0_0;
            let deferred0_1;
            try {
                deferred0_0 = arg0;
                deferred0_1 = arg1;
                console.error(getStringFromWasm0(arg0, arg1));
            } finally {
                wasm.__wbindgen_free(deferred0_0, deferred0_1, 1);
            }
        },
        __wbg_fetchmessage_new: function(arg0) {
            const ret = FetchMessage.__wrap(arg0);
            return ret;
        },
        __wbg_fetchobjectmessage_new: function(arg0) {
            const ret = FetchObjectMessage.__wrap(arg0);
            return ret;
        },
        __wbg_fetchokmessage_new: function(arg0) {
            const ret = FetchOkMessage.__wrap(arg0);
            return ret;
        },
        __wbg_fetchstreamendmessage_new: function(arg0) {
            const ret = FetchStreamEndMessage.__wrap(arg0);
            return ret;
        },
        __wbg_from_13e323c65fc8f464: function(arg0) {
            const ret = Array.from(arg0);
            return ret;
        },
        __wbg_getWriter_d71a99bcd847ccef: function() { return handleError(function (arg0) {
            const ret = arg0.getWriter();
            return ret;
        }, arguments); },
        __wbg_get_507a50627bffa49b: function(arg0, arg1) {
            const ret = arg0[arg1 >>> 0];
            return ret;
        },
        __wbg_get_78f252d074a84d0b: function() { return handleError(function (arg0, arg1) {
            const ret = Reflect.get(arg0, arg1);
            return ret;
        }, arguments); },
        __wbg_get_c7eb1f358a7654df: function() { return handleError(function (arg0, arg1) {
            const ret = Reflect.get(arg0, arg1);
            return ret;
        }, arguments); },
        __wbg_get_unchecked_6e0ad6d2a41b06f6: function(arg0, arg1) {
            const ret = arg0[arg1 >>> 0];
            return ret;
        },
        __wbg_get_with_ref_key_6412cf3094599694: function(arg0, arg1) {
            const ret = arg0[arg1];
            return ret;
        },
        __wbg_incomingUnidirectionalStreams_505a67efefd669d3: function(arg0) {
            const ret = arg0.incomingUnidirectionalStreams;
            return ret;
        },
        __wbg_instanceof_ArrayBuffer_4480b9e0068a8adb: function(arg0) {
            let result;
            try {
                result = arg0 instanceof ArrayBuffer;
            } catch (_) {
                result = false;
            }
            const ret = result;
            return ret;
        },
        __wbg_instanceof_Map_e5b5e3db98422fcc: function(arg0) {
            let result;
            try {
                result = arg0 instanceof Map;
            } catch (_) {
                result = false;
            }
            const ret = result;
            return ret;
        },
        __wbg_instanceof_Promise_4cb210c0b8f8c959: function(arg0) {
            let result;
            try {
                result = arg0 instanceof Promise;
            } catch (_) {
                result = false;
            }
            const ret = result;
            return ret;
        },
        __wbg_instanceof_Uint8Array_309b927aaf7a3fc7: function(arg0) {
            let result;
            try {
                result = arg0 instanceof Uint8Array;
            } catch (_) {
                result = false;
            }
            const ret = result;
            return ret;
        },
        __wbg_instanceof_WritableStream_0c8240a38930ffb4: function(arg0) {
            let result;
            try {
                result = arg0 instanceof WritableStream;
            } catch (_) {
                result = false;
            }
            const ret = result;
            return ret;
        },
        __wbg_isArray_0677c962b281d01a: function(arg0) {
            const ret = Array.isArray(arg0);
            return ret;
        },
        __wbg_isSafeInteger_04f36e4056f1b851: function(arg0) {
            const ret = Number.isSafeInteger(arg0);
            return ret;
        },
        __wbg_iterator_6f722e4a93058b71: function() {
            const ret = Symbol.iterator;
            return ret;
        },
        __wbg_length_1f0964f4a5e2c6d8: function(arg0) {
            const ret = arg0.length;
            return ret;
        },
        __wbg_length_370319915dc99107: function(arg0) {
            const ret = arg0.length;
            return ret;
        },
        __wbg_log_288e09fb0834f1d6: function(arg0, arg1) {
            console.log(getStringFromWasm0(arg0, arg1));
        },
        __wbg_namespaceokmessage_new: function(arg0) {
            const ret = NamespaceOkMessage.__wrap(arg0);
            return ret;
        },
        __wbg_new_227d7c05414eb861: function() {
            const ret = new Error();
            return ret;
        },
        __wbg_new_32b398fb48b6d94a: function() {
            const ret = new Array();
            return ret;
        },
        __wbg_new_86be1e4140bef8fd: function() { return handleError(function (arg0) {
            const ret = new ReadableStreamDefaultReader(arg0);
            return ret;
        }, arguments); },
        __wbg_new_a2778e1fb014b494: function() { return handleError(function (arg0, arg1) {
            const ret = new WebTransport(getStringFromWasm0(arg0, arg1));
            return ret;
        }, arguments); },
        __wbg_new_cd45aabdf6073e84: function(arg0) {
            const ret = new Uint8Array(arg0);
            return ret;
        },
        __wbg_new_da52cf8fe3429cb2: function() {
            const ret = new Object();
            return ret;
        },
        __wbg_new_typed_1824d93f294193e5: function(arg0, arg1) {
            try {
                var state0 = {a: arg0, b: arg1};
                var cb0 = (arg0, arg1) => {
                    const a = state0.a;
                    state0.a = 0;
                    try {
                        return wasm_bindgen__convert__closures_____invoke__h13298db01f47669e(a, state0.b, arg0, arg1);
                    } finally {
                        state0.a = a;
                    }
                };
                const ret = new Promise(cb0);
                return ret;
            } finally {
                state0.a = 0;
            }
        },
        __wbg_new_with_length_e6785c33c8e4cce8: function(arg0) {
            const ret = new Uint8Array(arg0 >>> 0);
            return ret;
        },
        __wbg_next_6dbf2c0ac8cde20f: function(arg0) {
            const ret = arg0.next;
            return ret;
        },
        __wbg_next_71f2aa1cb3d1e37e: function() { return handleError(function (arg0) {
            const ret = arg0.next();
            return ret;
        }, arguments); },
        __wbg_now_86c0d4ba3fa605b8: function() {
            const ret = Date.now();
            return ret;
        },
        __wbg_objectdatagrammessage_new: function(arg0) {
            const ret = ObjectDatagramMessage.__wrap(arg0);
            return ret;
        },
        __wbg_objectdatagramstatusmessage_new: function(arg0) {
            const ret = ObjectDatagramStatusMessage.__wrap(arg0);
            return ret;
        },
        __wbg_prototypesetcall_4770620bbe4688a0: function(arg0, arg1, arg2) {
            Uint8Array.prototype.set.call(getArrayU8FromWasm0(arg0, arg1), arg2);
        },
        __wbg_publishmessage_new: function(arg0) {
            const ret = PublishMessage.__wrap(arg0);
            return ret;
        },
        __wbg_publishnamespacedonemessage_new: function(arg0) {
            const ret = PublishNamespaceDoneMessage.__wrap(arg0);
            return ret;
        },
        __wbg_publishnamespacemessage_new: function(arg0) {
            const ret = PublishNamespaceMessage.__wrap(arg0);
            return ret;
        },
        __wbg_publishokmessage_new: function(arg0) {
            const ret = PublishOkMessage.__wrap(arg0);
            return ret;
        },
        __wbg_queueMicrotask_0ab5b2d2393e99b9: function(arg0) {
            const ret = arg0.queueMicrotask;
            return ret;
        },
        __wbg_queueMicrotask_6a09b7bc46549209: function(arg0) {
            queueMicrotask(arg0);
        },
        __wbg_read_8afa15f12a160ef8: function(arg0) {
            const ret = arg0.read();
            return ret;
        },
        __wbg_readable_41ceb106ca6ebcbe: function(arg0) {
            const ret = arg0.readable;
            return ret;
        },
        __wbg_readable_6ea71b5c81377287: function(arg0) {
            const ret = arg0.readable;
            return ret;
        },
        __wbg_ready_e4dad560377c42e6: function(arg0) {
            const ret = arg0.ready;
            return ret;
        },
        __wbg_requesterrormessage_new: function(arg0) {
            const ret = RequestErrorMessage.__wrap(arg0);
            return ret;
        },
        __wbg_resolve_2191a4dfe481c25b: function(arg0) {
            const ret = Promise.resolve(arg0);
            return ret;
        },
        __wbg_serversetupmessage_new: function(arg0) {
            const ret = ServerSetupMessage.__wrap(arg0);
            return ret;
        },
        __wbg_set_4d7dd76f3dae2926: function(arg0, arg1, arg2) {
            arg0.set(getArrayU8FromWasm0(arg1, arg2));
        },
        __wbg_set_6be42768c690e380: function(arg0, arg1, arg2) {
            arg0[arg1] = arg2;
        },
        __wbg_set_8a16b38e4805b298: function(arg0, arg1, arg2) {
            arg0[arg1 >>> 0] = arg2;
        },
        __wbg_stack_3b0d974bbf31e44f: function(arg0, arg1) {
            const ret = arg1.stack;
            const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
            getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
        },
        __wbg_static_accessor_GLOBAL_4ef717fb391d88b7: function() {
            const ret = typeof global === 'undefined' ? null : global;
            return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
        },
        __wbg_static_accessor_GLOBAL_THIS_8d1badc68b5a74f4: function() {
            const ret = typeof globalThis === 'undefined' ? null : globalThis;
            return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
        },
        __wbg_static_accessor_SELF_146583524fe1469b: function() {
            const ret = typeof self === 'undefined' ? null : self;
            return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
        },
        __wbg_static_accessor_WINDOW_f2829a2234d7819e: function() {
            const ret = typeof window === 'undefined' ? null : window;
            return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
        },
        __wbg_subgroupheadermessage_new: function(arg0) {
            const ret = SubgroupHeaderMessage.__wrap(arg0);
            return ret;
        },
        __wbg_subgroupobjectmessage_new: function(arg0) {
            const ret = SubgroupObjectMessage.__wrap(arg0);
            return ret;
        },
        __wbg_subscribemessage_new: function(arg0) {
            const ret = SubscribeMessage.__wrap(arg0);
            return ret;
        },
        __wbg_subscribeokmessage_new: function(arg0) {
            const ret = SubscribeOkMessage.__wrap(arg0);
            return ret;
        },
        __wbg_then_16d107c451e9905d: function(arg0, arg1, arg2) {
            const ret = arg0.then(arg1, arg2);
            return ret;
        },
        __wbg_then_6ec10ae38b3e92f7: function(arg0, arg1) {
            const ret = arg0.then(arg1);
            return ret;
        },
        __wbg_valueOf_cc637e7b8ebe8757: function(arg0) {
            const ret = arg0.valueOf();
            return ret;
        },
        __wbg_value_a5d5488a9589444a: function(arg0) {
            const ret = arg0.value;
            return ret;
        },
        __wbg_writable_c905da49f8095567: function(arg0) {
            const ret = arg0.writable;
            return ret;
        },
        __wbg_write_f6dc0059c3feedce: function(arg0, arg1) {
            const ret = arg0.write(arg1);
            return ret;
        },
        __wbindgen_cast_0000000000000001: function(arg0, arg1) {
            // Cast intrinsic for `Closure(Closure { owned: true, function: Function { arguments: [Externref], shim_idx: 313, ret: Result(Unit), inner_ret: Some(Result(Unit)) }, mutable: true }) -> Externref`.
            const ret = makeMutClosure(arg0, arg1, wasm_bindgen__convert__closures_____invoke__h5b3fa9a4add80240);
            return ret;
        },
        __wbindgen_cast_0000000000000002: function(arg0, arg1) {
            // Cast intrinsic for `Closure(Closure { owned: true, function: Function { arguments: [NamedExternref("WebTransportBidirectionalStream")], shim_idx: 108, ret: Result(Unit), inner_ret: Some(Result(Unit)) }, mutable: true }) -> Externref`.
            const ret = makeMutClosure(arg0, arg1, wasm_bindgen__convert__closures_____invoke__h4a33fe58a4250870);
            return ret;
        },
        __wbindgen_cast_0000000000000003: function(arg0, arg1) {
            // Cast intrinsic for `Closure(Closure { owned: true, function: Function { arguments: [NamedExternref("WebTransportSendStream")], shim_idx: 108, ret: Result(Unit), inner_ret: Some(Result(Unit)) }, mutable: true }) -> Externref`.
            const ret = makeMutClosure(arg0, arg1, wasm_bindgen__convert__closures_____invoke__h4a33fe58a4250870_2);
            return ret;
        },
        __wbindgen_cast_0000000000000004: function(arg0, arg1) {
            // Cast intrinsic for `Closure(Closure { owned: true, function: Function { arguments: [NamedExternref("undefined")], shim_idx: 108, ret: Result(Unit), inner_ret: Some(Result(Unit)) }, mutable: true }) -> Externref`.
            const ret = makeMutClosure(arg0, arg1, wasm_bindgen__convert__closures_____invoke__h4a33fe58a4250870_3);
            return ret;
        },
        __wbindgen_cast_0000000000000005: function(arg0) {
            // Cast intrinsic for `F64 -> Externref`.
            const ret = arg0;
            return ret;
        },
        __wbindgen_cast_0000000000000006: function(arg0) {
            // Cast intrinsic for `I64 -> Externref`.
            const ret = arg0;
            return ret;
        },
        __wbindgen_cast_0000000000000007: function(arg0, arg1) {
            // Cast intrinsic for `Ref(Slice(U8)) -> NamedExternref("Uint8Array")`.
            const ret = getArrayU8FromWasm0(arg0, arg1);
            return ret;
        },
        __wbindgen_cast_0000000000000008: function(arg0, arg1) {
            // Cast intrinsic for `Ref(String) -> Externref`.
            const ret = getStringFromWasm0(arg0, arg1);
            return ret;
        },
        __wbindgen_cast_0000000000000009: function(arg0) {
            // Cast intrinsic for `U64 -> Externref`.
            const ret = BigInt.asUintN(64, arg0);
            return ret;
        },
        __wbindgen_init_externref_table: function() {
            const table = wasm.__wbindgen_externrefs;
            const offset = table.grow(4);
            table.set(0, undefined);
            table.set(offset + 0, undefined);
            table.set(offset + 1, null);
            table.set(offset + 2, true);
            table.set(offset + 3, false);
        },
    };
    return {
        __proto__: null,
        "./moqt_client_wasm_bg.js": import0,
    };
}

function wasm_bindgen__convert__closures_____invoke__h5b3fa9a4add80240(arg0, arg1, arg2) {
    const ret = wasm.wasm_bindgen__convert__closures_____invoke__h5b3fa9a4add80240(arg0, arg1, arg2);
    if (ret[1]) {
        throw takeFromExternrefTable0(ret[0]);
    }
}

function wasm_bindgen__convert__closures_____invoke__h4a33fe58a4250870(arg0, arg1, arg2) {
    const ret = wasm.wasm_bindgen__convert__closures_____invoke__h4a33fe58a4250870(arg0, arg1, arg2);
    if (ret[1]) {
        throw takeFromExternrefTable0(ret[0]);
    }
}

function wasm_bindgen__convert__closures_____invoke__h4a33fe58a4250870_2(arg0, arg1, arg2) {
    const ret = wasm.wasm_bindgen__convert__closures_____invoke__h4a33fe58a4250870_2(arg0, arg1, arg2);
    if (ret[1]) {
        throw takeFromExternrefTable0(ret[0]);
    }
}

function wasm_bindgen__convert__closures_____invoke__h4a33fe58a4250870_3(arg0, arg1, arg2) {
    const ret = wasm.wasm_bindgen__convert__closures_____invoke__h4a33fe58a4250870_3(arg0, arg1, arg2);
    if (ret[1]) {
        throw takeFromExternrefTable0(ret[0]);
    }
}

function wasm_bindgen__convert__closures_____invoke__h13298db01f47669e(arg0, arg1, arg2, arg3) {
    wasm.wasm_bindgen__convert__closures_____invoke__h13298db01f47669e(arg0, arg1, arg2, arg3);
}

const FetchMessageFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_fetchmessage_free(ptr, 1));
const FetchObjectMessageFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_fetchobjectmessage_free(ptr, 1));
const FetchOkMessageFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_fetchokmessage_free(ptr, 1));
const FetchStreamEndMessageFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_fetchstreamendmessage_free(ptr, 1));
const MOQTClientFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_moqtclient_free(ptr, 1));
const Mp4AudioTrackFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_mp4audiotrack_free(ptr, 1));
const Mp4IndexFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_mp4index_free(ptr, 1));
const Mp4SampleTableFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_mp4sampletable_free(ptr, 1));
const Mp4VideoTrackFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_mp4videotrack_free(ptr, 1));
const NamespaceOkMessageFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_namespaceokmessage_free(ptr, 1));
const ObjectDatagramMessageFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_objectdatagrammessage_free(ptr, 1));
const ObjectDatagramStatusMessageFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_objectdatagramstatusmessage_free(ptr, 1));
const PublishMessageFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_publishmessage_free(ptr, 1));
const PublishNamespaceDoneMessageFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_publishnamespacedonemessage_free(ptr, 1));
const PublishNamespaceMessageFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_publishnamespacemessage_free(ptr, 1));
const PublishOkMessageFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_publishokmessage_free(ptr, 1));
const RequestErrorMessageFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_requesterrormessage_free(ptr, 1));
const ServerSetupMessageFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_serversetupmessage_free(ptr, 1));
const SubgroupHeaderMessageFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_subgroupheadermessage_free(ptr, 1));
const SubgroupObjectMessageFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_subgroupobjectmessage_free(ptr, 1));
const SubgroupStateFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_subgroupstate_free(ptr, 1));
const SubscribeMessageFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_subscribemessage_free(ptr, 1));
const SubscribeNamespaceMessageFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_subscribenamespacemessage_free(ptr, 1));
const SubscribeOkMessageFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_subscribeokmessage_free(ptr, 1));

function addToExternrefTable0(obj) {
    const idx = wasm.__externref_table_alloc();
    wasm.__wbindgen_externrefs.set(idx, obj);
    return idx;
}

const CLOSURE_DTORS = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(state => wasm.__wbindgen_destroy_closure(state.a, state.b));

function debugString(val) {
    // primitive types
    const type = typeof val;
    if (type == 'number' || type == 'boolean' || val == null) {
        return  `${val}`;
    }
    if (type == 'string') {
        return `"${val}"`;
    }
    if (type == 'symbol') {
        const description = val.description;
        if (description == null) {
            return 'Symbol';
        } else {
            return `Symbol(${description})`;
        }
    }
    if (type == 'function') {
        const name = val.name;
        if (typeof name == 'string' && name.length > 0) {
            return `Function(${name})`;
        } else {
            return 'Function';
        }
    }
    // objects
    if (Array.isArray(val)) {
        const length = val.length;
        let debug = '[';
        if (length > 0) {
            debug += debugString(val[0]);
        }
        for(let i = 1; i < length; i++) {
            debug += ', ' + debugString(val[i]);
        }
        debug += ']';
        return debug;
    }
    // Test for built-in
    const builtInMatches = /\[object ([^\]]+)\]/.exec(toString.call(val));
    let className;
    if (builtInMatches && builtInMatches.length > 1) {
        className = builtInMatches[1];
    } else {
        // Failed to match the standard '[object ClassName]'
        return toString.call(val);
    }
    if (className == 'Object') {
        // we're a user defined class or Object
        // JSON.stringify avoids problems with cycles, and is generally much
        // easier than looping through ownProperties of `val`.
        try {
            return 'Object(' + JSON.stringify(val) + ')';
        } catch (_) {
            return 'Object';
        }
    }
    // errors
    if (val instanceof Error) {
        return `${val.name}: ${val.message}\n${val.stack}`;
    }
    // TODO we could test for more things here, like `Set`s and `Map`s.
    return className;
}

function getArrayF64FromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    return getFloat64ArrayMemory0().subarray(ptr / 8, ptr / 8 + len);
}

function getArrayJsValueFromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    const mem = getDataViewMemory0();
    const result = [];
    for (let i = ptr; i < ptr + 4 * len; i += 4) {
        result.push(wasm.__wbindgen_externrefs.get(mem.getUint32(i, true)));
    }
    wasm.__externref_drop_slice(ptr, len);
    return result;
}

function getArrayU32FromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    return getUint32ArrayMemory0().subarray(ptr / 4, ptr / 4 + len);
}

function getArrayU64FromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    return getBigUint64ArrayMemory0().subarray(ptr / 8, ptr / 8 + len);
}

function getArrayU8FromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    return getUint8ArrayMemory0().subarray(ptr / 1, ptr / 1 + len);
}

let cachedBigUint64ArrayMemory0 = null;
function getBigUint64ArrayMemory0() {
    if (cachedBigUint64ArrayMemory0 === null || cachedBigUint64ArrayMemory0.byteLength === 0) {
        cachedBigUint64ArrayMemory0 = new BigUint64Array(wasm.memory.buffer);
    }
    return cachedBigUint64ArrayMemory0;
}

let cachedDataViewMemory0 = null;
function getDataViewMemory0() {
    if (cachedDataViewMemory0 === null || cachedDataViewMemory0.buffer.detached === true || (cachedDataViewMemory0.buffer.detached === undefined && cachedDataViewMemory0.buffer !== wasm.memory.buffer)) {
        cachedDataViewMemory0 = new DataView(wasm.memory.buffer);
    }
    return cachedDataViewMemory0;
}

let cachedFloat64ArrayMemory0 = null;
function getFloat64ArrayMemory0() {
    if (cachedFloat64ArrayMemory0 === null || cachedFloat64ArrayMemory0.byteLength === 0) {
        cachedFloat64ArrayMemory0 = new Float64Array(wasm.memory.buffer);
    }
    return cachedFloat64ArrayMemory0;
}

function getStringFromWasm0(ptr, len) {
    return decodeText(ptr >>> 0, len);
}

let cachedUint32ArrayMemory0 = null;
function getUint32ArrayMemory0() {
    if (cachedUint32ArrayMemory0 === null || cachedUint32ArrayMemory0.byteLength === 0) {
        cachedUint32ArrayMemory0 = new Uint32Array(wasm.memory.buffer);
    }
    return cachedUint32ArrayMemory0;
}

let cachedUint8ArrayMemory0 = null;
function getUint8ArrayMemory0() {
    if (cachedUint8ArrayMemory0 === null || cachedUint8ArrayMemory0.byteLength === 0) {
        cachedUint8ArrayMemory0 = new Uint8Array(wasm.memory.buffer);
    }
    return cachedUint8ArrayMemory0;
}

function handleError(f, args) {
    try {
        return f.apply(this, args);
    } catch (e) {
        const idx = addToExternrefTable0(e);
        wasm.__wbindgen_exn_store(idx);
    }
}

function isLikeNone(x) {
    return x === undefined || x === null;
}

function makeMutClosure(arg0, arg1, f) {
    const state = { a: arg0, b: arg1, cnt: 1 };
    const real = (...args) => {

        // First up with a closure we increment the internal reference
        // count. This ensures that the Rust closure environment won't
        // be deallocated while we're invoking it.
        state.cnt++;
        const a = state.a;
        state.a = 0;
        try {
            return f(a, state.b, ...args);
        } finally {
            state.a = a;
            real._wbg_cb_unref();
        }
    };
    real._wbg_cb_unref = () => {
        if (--state.cnt === 0) {
            wasm.__wbindgen_destroy_closure(state.a, state.b);
            state.a = 0;
            CLOSURE_DTORS.unregister(state);
        }
    };
    CLOSURE_DTORS.register(real, state, state);
    return real;
}

function passArray32ToWasm0(arg, malloc) {
    const ptr = malloc(arg.length * 4, 4) >>> 0;
    getUint32ArrayMemory0().set(arg, ptr / 4);
    WASM_VECTOR_LEN = arg.length;
    return ptr;
}

function passArray64ToWasm0(arg, malloc) {
    const ptr = malloc(arg.length * 8, 8) >>> 0;
    getBigUint64ArrayMemory0().set(arg, ptr / 8);
    WASM_VECTOR_LEN = arg.length;
    return ptr;
}

function passArray8ToWasm0(arg, malloc) {
    const ptr = malloc(arg.length * 1, 1) >>> 0;
    getUint8ArrayMemory0().set(arg, ptr / 1);
    WASM_VECTOR_LEN = arg.length;
    return ptr;
}

function passArrayF64ToWasm0(arg, malloc) {
    const ptr = malloc(arg.length * 8, 8) >>> 0;
    getFloat64ArrayMemory0().set(arg, ptr / 8);
    WASM_VECTOR_LEN = arg.length;
    return ptr;
}

function passArrayJsValueToWasm0(array, malloc) {
    const ptr = malloc(array.length * 4, 4) >>> 0;
    for (let i = 0; i < array.length; i++) {
        const add = addToExternrefTable0(array[i]);
        getDataViewMemory0().setUint32(ptr + 4 * i, add, true);
    }
    WASM_VECTOR_LEN = array.length;
    return ptr;
}

function passStringToWasm0(arg, malloc, realloc) {
    if (realloc === undefined) {
        const buf = cachedTextEncoder.encode(arg);
        const ptr = malloc(buf.length, 1) >>> 0;
        getUint8ArrayMemory0().subarray(ptr, ptr + buf.length).set(buf);
        WASM_VECTOR_LEN = buf.length;
        return ptr;
    }

    let len = arg.length;
    let ptr = malloc(len, 1) >>> 0;

    const mem = getUint8ArrayMemory0();

    let offset = 0;

    for (; offset < len; offset++) {
        const code = arg.charCodeAt(offset);
        if (code > 0x7F) break;
        mem[ptr + offset] = code;
    }
    if (offset !== len) {
        if (offset !== 0) {
            arg = arg.slice(offset);
        }
        ptr = realloc(ptr, len, len = offset + arg.length * 3, 1) >>> 0;
        const view = getUint8ArrayMemory0().subarray(ptr + offset, ptr + len);
        const ret = cachedTextEncoder.encodeInto(arg, view);

        offset += ret.written;
        ptr = realloc(ptr, len, offset, 1) >>> 0;
    }

    WASM_VECTOR_LEN = offset;
    return ptr;
}

function takeFromExternrefTable0(idx) {
    const value = wasm.__wbindgen_externrefs.get(idx);
    wasm.__externref_table_dealloc(idx);
    return value;
}

let cachedTextDecoder = new TextDecoder('utf-8', { ignoreBOM: true, fatal: true });
cachedTextDecoder.decode();
const MAX_SAFARI_DECODE_BYTES = 2146435072;
let numBytesDecoded = 0;
function decodeText(ptr, len) {
    numBytesDecoded += len;
    if (numBytesDecoded >= MAX_SAFARI_DECODE_BYTES) {
        cachedTextDecoder = new TextDecoder('utf-8', { ignoreBOM: true, fatal: true });
        cachedTextDecoder.decode();
        numBytesDecoded = len;
    }
    return cachedTextDecoder.decode(getUint8ArrayMemory0().subarray(ptr, ptr + len));
}

const cachedTextEncoder = new TextEncoder();

if (!('encodeInto' in cachedTextEncoder)) {
    cachedTextEncoder.encodeInto = function (arg, view) {
        const buf = cachedTextEncoder.encode(arg);
        view.set(buf);
        return {
            read: arg.length,
            written: buf.length
        };
    };
}

let WASM_VECTOR_LEN = 0;

let wasmModule, wasmInstance, wasm;
function __wbg_finalize_init(instance, module) {
    wasmInstance = instance;
    wasm = instance.exports;
    wasmModule = module;
    cachedBigUint64ArrayMemory0 = null;
    cachedDataViewMemory0 = null;
    cachedFloat64ArrayMemory0 = null;
    cachedUint32ArrayMemory0 = null;
    cachedUint8ArrayMemory0 = null;
    wasm.__wbindgen_start();
    return wasm;
}

async function __wbg_load(module, imports) {
    if (typeof Response === 'function' && module instanceof Response) {
        if (typeof WebAssembly.instantiateStreaming === 'function') {
            try {
                return await WebAssembly.instantiateStreaming(module, imports);
            } catch (e) {
                const validResponse = module.ok && expectedResponseType(module.type);

                if (validResponse && module.headers.get('Content-Type') !== 'application/wasm') {
                    console.warn("`WebAssembly.instantiateStreaming` failed because your server does not serve Wasm with `application/wasm` MIME type. Falling back to `WebAssembly.instantiate` which is slower. Original error:\n", e);

                } else { throw e; }
            }
        }

        const bytes = await module.arrayBuffer();
        return await WebAssembly.instantiate(bytes, imports);
    } else {
        const instance = await WebAssembly.instantiate(module, imports);

        if (instance instanceof WebAssembly.Instance) {
            return { instance, module };
        } else {
            return instance;
        }
    }

    function expectedResponseType(type) {
        switch (type) {
            case 'basic': case 'cors': case 'default': return true;
        }
        return false;
    }
}

function initSync(module) {
    if (wasm !== undefined) return wasm;


    if (module !== undefined) {
        if (Object.getPrototypeOf(module) === Object.prototype) {
            ({module} = module)
        } else {
            console.warn('using deprecated parameters for `initSync()`; pass a single object instead')
        }
    }

    const imports = __wbg_get_imports();
    if (!(module instanceof WebAssembly.Module)) {
        module = new WebAssembly.Module(module);
    }
    const instance = new WebAssembly.Instance(module, imports);
    return __wbg_finalize_init(instance, module);
}

async function __wbg_init(module_or_path) {
    if (wasm !== undefined) return wasm;


    if (module_or_path !== undefined) {
        if (Object.getPrototypeOf(module_or_path) === Object.prototype) {
            ({module_or_path} = module_or_path)
        } else {
            console.warn('using deprecated parameters for the initialization function; pass a single object instead')
        }
    }

    if (module_or_path === undefined) {
        module_or_path = new URL('moqt_client_wasm_bg.wasm', import.meta.url);
    }
    const imports = __wbg_get_imports();

    if (typeof module_or_path === 'string' || (typeof Request === 'function' && module_or_path instanceof Request) || (typeof URL === 'function' && module_or_path instanceof URL)) {
        module_or_path = fetch(module_or_path);
    }

    const { instance, module } = await __wbg_load(await module_or_path, imports);

    return __wbg_finalize_init(instance, module);
}

export { initSync, __wbg_init as default };
