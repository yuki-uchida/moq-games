/* tslint:disable */
/* eslint-disable */

/**
 * The range is already resolved against the Largest Location this client
 * has sent: the end is the End Location its FETCH_OK carries (draft-14
 * §9.17), i.e. the Location after the last Object to send, where Object 0
 * covers the whole Group.
 */
export class FetchMessage {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    endGroupId: bigint;
    endObjectId: bigint;
    groupOrder: number;
    requestId: bigint;
    startGroupId: bigint;
    startObjectId: bigint;
    trackName: string;
    trackNamespace: string[];
}

export class FetchObjectMessage {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    readonly groupId: bigint;
    readonly locHeader: any;
    readonly objectId: bigint;
    readonly objectPayload: Uint8Array;
    readonly requestId: bigint;
}

export class FetchOkMessage {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    readonly endGroupId: bigint;
    readonly endObjectId: bigint;
    readonly endOfTrack: boolean;
    readonly requestId: bigint;
}

/**
 * How the relay ended a fetch stream: a FIN means every object up to the
 * FETCH_OK End Location has been delivered; a RESET_STREAM means objects may
 * be missing.
 */
export class FetchStreamEndMessage {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    readonly isReset: boolean;
    readonly requestId: bigint;
    readonly resetErrorCode: bigint | undefined;
}

export class MOQTClient {
    free(): void;
    [Symbol.dispose](): void;
    close(): Promise<void>;
    finishFetch(request_id: bigint): Promise<void>;
    getSubgroupState(track_alias: bigint): SubgroupState;
    getTrackSubscribers(track_namespace: string[], track_name: string): BigUint64Array;
    incrementSubgroupObject(track_alias: bigint): void;
    isConnected(): boolean;
    isSubscribed(request_id: bigint): boolean;
    markSubgroupHeaderSent(track_alias: bigint): void;
    constructor(url: string);
    onConnectionClosed(callback: Function): void;
    onFetch(callback: Function): void;
    onFetchCancel(callback: Function): void;
    onFetchObject(callback: Function): void;
    onFetchResponse(callback: Function): void;
    onFetchStreamEnd(callback: Function): void;
    onIncomingUnsubscribe(callback: Function): void;
    onObjectDatagram(callback: Function): void;
    onObjectDatagramStatus(callback: Function): void;
    onPublish(callback: Function): void;
    onPublishNamespace(callback: Function): void;
    onPublishNamespaceDone(callback: Function): void;
    onPublishNamespaceResponse(callback: Function): void;
    onPublishResponse(callback: Function): void;
    onServerSetup(callback: Function): void;
    onSubgroupHeader(callback: Function): void;
    onSubgroupObject(callback: Function): void;
    onSubscribe(callback: Function): void;
    onSubscribeNamespaceResponse(callback: Function): void;
    onSubscribeResponse(callback: Function): void;
    onTrackStatus(callback: Function): void;
    onTrackStatusResponse(callback: Function): void;
    resetSubgroupState(track_alias: bigint): void;
    sendClientSetup(versions: BigUint64Array, max_request_id: bigint, auth_token?: string | null): Promise<void>;
    sendFetch(request_id: bigint, track_namespace: string[], track_name: string, start_group: bigint, start_object: bigint, end_group: bigint, end_object: bigint, group_order: number): Promise<void>;
    sendFetchCancel(request_id: bigint): Promise<void>;
    sendFetchError(request_id: bigint, error_code: bigint, reason_phrase: string): Promise<void>;
    sendFetchObject(request_id: bigint, group_id: bigint, subgroup_id: bigint, object_id: bigint, publisher_priority: number, object_status: number | null | undefined, object_payload: Uint8Array, loc_header: any): Promise<void>;
    sendFetchOk(request_id: bigint): Promise<void>;
    sendGoAway(new_session_uri: string): Promise<void>;
    sendMaxRequestId(request_id: bigint): Promise<void>;
    sendObjectDatagram(track_alias: bigint, group_id: bigint, object_id: bigint, publisher_priority: number, object_payload: Uint8Array, loc_header: any): Promise<void>;
    sendObjectDatagramStatus(track_alias: bigint, group_id: bigint, object_id: bigint, publisher_priority: number, object_status: number, loc_header: any): Promise<void>;
    sendPublish(request_id: bigint, track_namespace: string[], track_name: string, track_alias: bigint | null | undefined, group_order: number, content_exists: boolean, largest_group_id: bigint | null | undefined, largest_object_id: bigint | null | undefined, forward: boolean, auth_info: string): Promise<bigint>;
    sendPublishDone(request_id: bigint, status_code: bigint, stream_count: bigint, error_reason: string): Promise<void>;
    sendPublishError(request_id: bigint, error_code: bigint, reason_phrase: string): Promise<void>;
    sendPublishNamespace(request_id: bigint, track_namespace: string[], auth_info: string): Promise<void>;
    sendPublishNamespaceCancel(track_namespace: string[], error_code: bigint, error_reason: string): Promise<void>;
    sendPublishNamespaceDone(track_namespace: string[]): Promise<void>;
    sendPublishNamespaceError(request_id: bigint, error_code: bigint, reason_phrase: string): Promise<void>;
    sendPublishNamespaceOk(request_id: bigint): Promise<void>;
    sendPublishOk(request_id: bigint, subscriber_priority: number, group_order: number, filter_type: number, start_group: bigint | null | undefined, start_object: bigint | null | undefined, end_group: bigint | null | undefined, delivery_timeout: bigint | null | undefined, forward: boolean): Promise<void>;
    sendRelativeJoiningFetch(request_id: bigint, joining_request_id: bigint, joining_start: bigint, group_order: number): Promise<void>;
    sendRequestsBlocked(maximum_request_id: bigint): Promise<void>;
    sendSubgroupHeader(track_alias: bigint, group_id: bigint, subgroup_id: bigint, publisher_priority: number): Promise<void>;
    sendSubgroupObject(track_alias: bigint, group_id: bigint, subgroup_id: bigint, object_number: bigint, object_status: number | null | undefined, object_payload: Uint8Array, loc_header: any): Promise<void>;
    sendSubscribe(request_id: bigint, track_namespace: string[], track_name: string, subscriber_priority: number, group_order: number, filter_type: number, start_group: bigint | null | undefined, start_object: bigint | null | undefined, end_group: bigint | null | undefined, auth_info: string, forward: boolean, delivery_timeout?: bigint | null): Promise<void>;
    sendSubscribeError(request_id: bigint, error_code: bigint, reason_phrase: string): Promise<void>;
    sendSubscribeForward(request_id: bigint, subscription_request_id: bigint, forward: boolean): Promise<void>;
    sendSubscribeNamespace(request_id: bigint, track_namespace_prefix: string[], auth_info: string): Promise<void>;
    sendSubscribeOk(request_id: bigint, expires: bigint, delivery_timeout?: bigint | null, max_duration?: bigint | null): Promise<bigint>;
    sendSubscribeUpdate(request_id: bigint, subscription_request_id: bigint, start_group: bigint, start_object: bigint, end_group: bigint, subscriber_priority: number, forward: boolean): Promise<void>;
    sendTrackStatus(request_id: bigint, track_namespace: string[], track_name: string, auth_info: string): Promise<void>;
    sendTrackStatusError(request_id: bigint, error_code: bigint, reason_phrase: string): Promise<void>;
    sendTrackStatusOk(request_id: bigint): Promise<void>;
    sendUnsubscribe(request_id: bigint): Promise<void>;
    sendUnsubscribeNamespace(track_namespace_prefix: string[]): Promise<void>;
    start(): Promise<void>;
    url(): any;
}

export class Mp4AudioTrack {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    get audioSpecificConfig(): Uint8Array | undefined;
    set audioSpecificConfig(value: Uint8Array | null | undefined);
    channels: number;
    codec: string;
    sampleRate: number;
}

/**
 * Indexes a progressive MP4 from its `moov` atom, so a page can read the
 * samples of a large file from a `Blob` range by range instead of loading
 * the whole file into wasm memory.
 */
export class Mp4Index {
    free(): void;
    [Symbol.dispose](): void;
    annexBVideoSample(avcc: Uint8Array, sync: boolean): Uint8Array;
    audio(): Mp4AudioTrack | undefined;
    durationMicros(): number;
    constructor(moov: Uint8Array);
    reorderDelayMicros(): number;
    samples(): Mp4SampleTable;
    video(): Mp4VideoTrack | undefined;
}

/**
 * The sample table as parallel columns, one entry per sample in decode
 * order: `kind` is 0 for video and 1 for audio, `sync` is 1 for a keyframe.
 */
export class Mp4SampleTable {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    dtsMicros: Float64Array;
    kind: Uint8Array;
    offset: Float64Array;
    ptsMicros: Float64Array;
    size: Uint32Array;
    sync: Uint8Array;
}

export class Mp4VideoTrack {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    codec: string;
    height: number;
    width: number;
}

export class NamespaceOkMessage {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    readonly requestId: bigint;
}

export class ObjectDatagramMessage {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    readonly groupId: bigint;
    readonly locHeader: any;
    readonly objectId: bigint | undefined;
    readonly objectPayload: Uint8Array;
    readonly objectPayloadLength: number;
    readonly publisherPriority: number;
    readonly trackAlias: bigint;
}

export class ObjectDatagramStatusMessage {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    readonly groupId: bigint;
    readonly locHeader: any;
    readonly objectId: bigint | undefined;
    readonly objectStatus: number;
    readonly publisherPriority: number;
    readonly trackAlias: bigint;
}

export class PublishMessage {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    readonly contentExists: boolean;
    readonly forward: boolean;
    readonly groupOrder: number;
    readonly largestGroupId: bigint | undefined;
    readonly largestObjectId: bigint | undefined;
    readonly requestId: bigint;
    readonly trackAlias: bigint;
    readonly trackName: string;
    readonly trackNamespace: string[];
}

export class PublishNamespaceDoneMessage {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    readonly trackNamespace: string[];
}

export class PublishNamespaceMessage {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    readonly requestId: bigint;
    readonly trackNamespace: string[];
}

export class PublishOkMessage {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    readonly deliveryTimeout: bigint | undefined;
    readonly endGroup: bigint | undefined;
    readonly filterType: number;
    readonly forward: boolean;
    readonly groupOrder: number;
    readonly requestId: bigint;
    readonly startGroup: bigint | undefined;
    readonly startObject: bigint | undefined;
    readonly subscriberPriority: number;
}

export class RequestErrorMessage {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    readonly errorCode: bigint;
    readonly reasonPhrase: string;
    readonly requestId: bigint;
}

export class ServerSetupMessage {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    readonly maxRequestId: bigint;
    readonly version: number;
}

export class SubgroupHeaderMessage {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    readonly groupId: bigint;
    readonly publisherPriority: number;
    readonly subgroupId: bigint | undefined;
    readonly trackAlias: bigint;
}

export class SubgroupObjectMessage {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    readonly locHeader: any;
    readonly objectId: bigint;
    readonly objectIdDelta: bigint;
    readonly objectPayload: Uint8Array;
    readonly objectPayloadLength: number;
    readonly objectStatus: number | undefined;
    readonly subgroupId: bigint | undefined;
}

/**
 * JavaScript-friendly wrapper for subgroup send state
 */
export class SubgroupState {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    readonly groupId: bigint;
    readonly headerSent: boolean;
    readonly objectId: bigint;
    readonly subgroupId: bigint;
    readonly trackAlias: bigint;
}

export class SubscribeMessage {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    readonly endGroup: bigint | undefined;
    readonly filterType: number;
    readonly forward: boolean;
    readonly groupOrder: number;
    readonly requestId: bigint;
    readonly startGroup: bigint | undefined;
    readonly startObject: bigint | undefined;
    readonly subscriberPriority: number;
    readonly trackName: string;
    readonly trackNamespace: string[];
}

export class SubscribeNamespaceMessage {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    readonly requestId: bigint;
    readonly trackNamespacePrefix: string[];
}

export class SubscribeOkMessage {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    readonly contentExists: boolean;
    readonly deliveryTimeout: bigint | undefined;
    readonly expires: bigint;
    readonly groupOrder: number;
    readonly largestGroupId: bigint | undefined;
    readonly largestObjectId: bigint | undefined;
    readonly maxDuration: bigint | undefined;
    readonly requestId: bigint;
    readonly trackAlias: bigint;
}

export function main(): void;

export function msf_catalog_to_json(value: any): string;

export function parse_msf_catalog_json(json: string): any;

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
    readonly memory: WebAssembly.Memory;
    readonly __wbg_fetchmessage_free: (a: number, b: number) => void;
    readonly __wbg_fetchobjectmessage_free: (a: number, b: number) => void;
    readonly __wbg_fetchokmessage_free: (a: number, b: number) => void;
    readonly __wbg_fetchstreamendmessage_free: (a: number, b: number) => void;
    readonly __wbg_get_fetchmessage_endGroupId: (a: number) => bigint;
    readonly __wbg_get_fetchmessage_endObjectId: (a: number) => bigint;
    readonly __wbg_get_fetchmessage_groupOrder: (a: number) => number;
    readonly __wbg_get_fetchmessage_requestId: (a: number) => bigint;
    readonly __wbg_get_fetchmessage_startGroupId: (a: number) => bigint;
    readonly __wbg_get_fetchmessage_startObjectId: (a: number) => bigint;
    readonly __wbg_get_fetchmessage_trackName: (a: number) => [number, number];
    readonly __wbg_get_fetchmessage_trackNamespace: (a: number) => [number, number];
    readonly __wbg_namespaceokmessage_free: (a: number, b: number) => void;
    readonly __wbg_objectdatagrammessage_free: (a: number, b: number) => void;
    readonly __wbg_objectdatagramstatusmessage_free: (a: number, b: number) => void;
    readonly __wbg_publishmessage_free: (a: number, b: number) => void;
    readonly __wbg_publishnamespacedonemessage_free: (a: number, b: number) => void;
    readonly __wbg_publishnamespacemessage_free: (a: number, b: number) => void;
    readonly __wbg_publishokmessage_free: (a: number, b: number) => void;
    readonly __wbg_requesterrormessage_free: (a: number, b: number) => void;
    readonly __wbg_serversetupmessage_free: (a: number, b: number) => void;
    readonly __wbg_set_fetchmessage_endGroupId: (a: number, b: bigint) => void;
    readonly __wbg_set_fetchmessage_endObjectId: (a: number, b: bigint) => void;
    readonly __wbg_set_fetchmessage_groupOrder: (a: number, b: number) => void;
    readonly __wbg_set_fetchmessage_requestId: (a: number, b: bigint) => void;
    readonly __wbg_set_fetchmessage_startGroupId: (a: number, b: bigint) => void;
    readonly __wbg_set_fetchmessage_startObjectId: (a: number, b: bigint) => void;
    readonly __wbg_set_fetchmessage_trackName: (a: number, b: number, c: number) => void;
    readonly __wbg_set_fetchmessage_trackNamespace: (a: number, b: number, c: number) => void;
    readonly __wbg_subgroupheadermessage_free: (a: number, b: number) => void;
    readonly __wbg_subgroupobjectmessage_free: (a: number, b: number) => void;
    readonly __wbg_subscribemessage_free: (a: number, b: number) => void;
    readonly __wbg_subscribenamespacemessage_free: (a: number, b: number) => void;
    readonly __wbg_subscribeokmessage_free: (a: number, b: number) => void;
    readonly fetchobjectmessage_groupId: (a: number) => bigint;
    readonly fetchobjectmessage_locHeader: (a: number) => [number, number, number];
    readonly fetchobjectmessage_objectId: (a: number) => bigint;
    readonly fetchobjectmessage_objectPayload: (a: number) => [number, number];
    readonly fetchobjectmessage_requestId: (a: number) => bigint;
    readonly fetchokmessage_endOfTrack: (a: number) => number;
    readonly fetchstreamendmessage_isReset: (a: number) => number;
    readonly fetchstreamendmessage_resetErrorCode: (a: number) => [number, bigint];
    readonly objectdatagrammessage_groupId: (a: number) => bigint;
    readonly objectdatagrammessage_locHeader: (a: number) => [number, number, number];
    readonly objectdatagrammessage_objectPayload: (a: number) => [number, number];
    readonly objectdatagrammessage_objectPayloadLength: (a: number) => number;
    readonly objectdatagrammessage_publisherPriority: (a: number) => number;
    readonly objectdatagramstatusmessage_locHeader: (a: number) => [number, number, number];
    readonly objectdatagramstatusmessage_objectStatus: (a: number) => number;
    readonly objectdatagramstatusmessage_publisherPriority: (a: number) => number;
    readonly publishmessage_contentExists: (a: number) => number;
    readonly publishmessage_forward: (a: number) => number;
    readonly publishmessage_groupOrder: (a: number) => number;
    readonly publishmessage_largestObjectId: (a: number) => [number, bigint];
    readonly publishmessage_requestId: (a: number) => bigint;
    readonly publishmessage_trackAlias: (a: number) => bigint;
    readonly publishmessage_trackName: (a: number) => [number, number];
    readonly publishmessage_trackNamespace: (a: number) => [number, number];
    readonly publishnamespacedonemessage_trackNamespace: (a: number) => [number, number];
    readonly publishnamespacemessage_trackNamespace: (a: number) => [number, number];
    readonly publishokmessage_deliveryTimeout: (a: number) => [number, bigint];
    readonly publishokmessage_endGroup: (a: number) => [number, bigint];
    readonly publishokmessage_filterType: (a: number) => number;
    readonly publishokmessage_requestId: (a: number) => bigint;
    readonly publishokmessage_subscriberPriority: (a: number) => number;
    readonly requesterrormessage_reasonPhrase: (a: number) => [number, number];
    readonly serversetupmessage_version: (a: number) => number;
    readonly subgroupheadermessage_publisherPriority: (a: number) => number;
    readonly subgroupobjectmessage_locHeader: (a: number) => [number, number, number];
    readonly subgroupobjectmessage_objectPayload: (a: number) => [number, number];
    readonly subgroupobjectmessage_objectStatus: (a: number) => number;
    readonly subscribemessage_filterType: (a: number) => number;
    readonly subscribemessage_forward: (a: number) => number;
    readonly subscribemessage_groupOrder: (a: number) => number;
    readonly subscribemessage_requestId: (a: number) => bigint;
    readonly subscribemessage_subscriberPriority: (a: number) => number;
    readonly subscribemessage_trackName: (a: number) => [number, number];
    readonly subscribemessage_trackNamespace: (a: number) => [number, number];
    readonly subscribenamespacemessage_trackNamespacePrefix: (a: number) => [number, number];
    readonly subscribeokmessage_contentExists: (a: number) => number;
    readonly subscribeokmessage_expires: (a: number) => bigint;
    readonly subscribeokmessage_groupOrder: (a: number) => number;
    readonly subscribeokmessage_trackAlias: (a: number) => bigint;
    readonly objectdatagrammessage_objectId: (a: number) => [number, bigint];
    readonly objectdatagramstatusmessage_objectId: (a: number) => [number, bigint];
    readonly publishmessage_largestGroupId: (a: number) => [number, bigint];
    readonly publishokmessage_startGroup: (a: number) => [number, bigint];
    readonly publishokmessage_startObject: (a: number) => [number, bigint];
    readonly subgroupheadermessage_subgroupId: (a: number) => [number, bigint];
    readonly subgroupobjectmessage_subgroupId: (a: number) => [number, bigint];
    readonly subscribemessage_endGroup: (a: number) => [number, bigint];
    readonly subscribemessage_startGroup: (a: number) => [number, bigint];
    readonly subscribemessage_startObject: (a: number) => [number, bigint];
    readonly subscribeokmessage_deliveryTimeout: (a: number) => [number, bigint];
    readonly subscribeokmessage_largestGroupId: (a: number) => [number, bigint];
    readonly subscribeokmessage_largestObjectId: (a: number) => [number, bigint];
    readonly subscribeokmessage_maxDuration: (a: number) => [number, bigint];
    readonly fetchokmessage_endGroupId: (a: number) => bigint;
    readonly fetchokmessage_endObjectId: (a: number) => bigint;
    readonly fetchokmessage_requestId: (a: number) => bigint;
    readonly fetchstreamendmessage_requestId: (a: number) => bigint;
    readonly namespaceokmessage_requestId: (a: number) => bigint;
    readonly objectdatagrammessage_trackAlias: (a: number) => bigint;
    readonly objectdatagramstatusmessage_groupId: (a: number) => bigint;
    readonly objectdatagramstatusmessage_trackAlias: (a: number) => bigint;
    readonly publishnamespacemessage_requestId: (a: number) => bigint;
    readonly requesterrormessage_errorCode: (a: number) => bigint;
    readonly requesterrormessage_requestId: (a: number) => bigint;
    readonly serversetupmessage_maxRequestId: (a: number) => bigint;
    readonly subgroupheadermessage_groupId: (a: number) => bigint;
    readonly subgroupheadermessage_trackAlias: (a: number) => bigint;
    readonly subgroupobjectmessage_objectId: (a: number) => bigint;
    readonly subgroupobjectmessage_objectIdDelta: (a: number) => bigint;
    readonly subgroupobjectmessage_objectPayloadLength: (a: number) => number;
    readonly subscribenamespacemessage_requestId: (a: number) => bigint;
    readonly subscribeokmessage_requestId: (a: number) => bigint;
    readonly publishokmessage_forward: (a: number) => number;
    readonly publishokmessage_groupOrder: (a: number) => number;
    readonly __wbg_moqtclient_free: (a: number, b: number) => void;
    readonly main: () => void;
    readonly moqtclient_close: (a: number) => any;
    readonly moqtclient_finishFetch: (a: number, b: bigint) => any;
    readonly moqtclient_getSubgroupState: (a: number, b: bigint) => number;
    readonly moqtclient_getTrackSubscribers: (a: number, b: number, c: number, d: number, e: number) => [number, number];
    readonly moqtclient_incrementSubgroupObject: (a: number, b: bigint) => void;
    readonly moqtclient_isConnected: (a: number) => number;
    readonly moqtclient_isSubscribed: (a: number, b: bigint) => number;
    readonly moqtclient_markSubgroupHeaderSent: (a: number, b: bigint) => void;
    readonly moqtclient_new: (a: number, b: number) => number;
    readonly moqtclient_onConnectionClosed: (a: number, b: any) => void;
    readonly moqtclient_onFetch: (a: number, b: any) => void;
    readonly moqtclient_onFetchCancel: (a: number, b: any) => void;
    readonly moqtclient_onFetchObject: (a: number, b: any) => void;
    readonly moqtclient_onFetchResponse: (a: number, b: any) => void;
    readonly moqtclient_onFetchStreamEnd: (a: number, b: any) => void;
    readonly moqtclient_onIncomingUnsubscribe: (a: number, b: any) => void;
    readonly moqtclient_onObjectDatagram: (a: number, b: any) => void;
    readonly moqtclient_onObjectDatagramStatus: (a: number, b: any) => void;
    readonly moqtclient_onPublish: (a: number, b: any) => void;
    readonly moqtclient_onPublishNamespace: (a: number, b: any) => void;
    readonly moqtclient_onPublishNamespaceDone: (a: number, b: any) => void;
    readonly moqtclient_onPublishNamespaceResponse: (a: number, b: any) => void;
    readonly moqtclient_onPublishResponse: (a: number, b: any) => void;
    readonly moqtclient_onServerSetup: (a: number, b: any) => void;
    readonly moqtclient_onSubgroupHeader: (a: number, b: any) => void;
    readonly moqtclient_onSubgroupObject: (a: number, b: any) => void;
    readonly moqtclient_onSubscribe: (a: number, b: any) => void;
    readonly moqtclient_onSubscribeNamespaceResponse: (a: number, b: any) => void;
    readonly moqtclient_onSubscribeResponse: (a: number, b: any) => void;
    readonly moqtclient_onTrackStatus: (a: number, b: any) => void;
    readonly moqtclient_onTrackStatusResponse: (a: number, b: any) => void;
    readonly moqtclient_resetSubgroupState: (a: number, b: bigint) => void;
    readonly moqtclient_sendClientSetup: (a: number, b: number, c: number, d: bigint, e: number, f: number) => any;
    readonly moqtclient_sendFetch: (a: number, b: bigint, c: number, d: number, e: number, f: number, g: bigint, h: bigint, i: bigint, j: bigint, k: number) => any;
    readonly moqtclient_sendFetchCancel: (a: number, b: bigint) => any;
    readonly moqtclient_sendFetchError: (a: number, b: bigint, c: bigint, d: number, e: number) => any;
    readonly moqtclient_sendFetchObject: (a: number, b: bigint, c: bigint, d: bigint, e: bigint, f: number, g: number, h: number, i: number, j: any) => any;
    readonly moqtclient_sendFetchOk: (a: number, b: bigint) => any;
    readonly moqtclient_sendGoAway: (a: number, b: number, c: number) => any;
    readonly moqtclient_sendMaxRequestId: (a: number, b: bigint) => any;
    readonly moqtclient_sendObjectDatagram: (a: number, b: bigint, c: bigint, d: bigint, e: number, f: number, g: number, h: any) => any;
    readonly moqtclient_sendObjectDatagramStatus: (a: number, b: bigint, c: bigint, d: bigint, e: number, f: number, g: any) => any;
    readonly moqtclient_sendPublish: (a: number, b: bigint, c: number, d: number, e: number, f: number, g: number, h: bigint, i: number, j: number, k: number, l: bigint, m: number, n: bigint, o: number, p: number, q: number) => any;
    readonly moqtclient_sendPublishDone: (a: number, b: bigint, c: bigint, d: bigint, e: number, f: number) => any;
    readonly moqtclient_sendPublishError: (a: number, b: bigint, c: bigint, d: number, e: number) => any;
    readonly moqtclient_sendPublishNamespace: (a: number, b: bigint, c: number, d: number, e: number, f: number) => any;
    readonly moqtclient_sendPublishNamespaceCancel: (a: number, b: number, c: number, d: bigint, e: number, f: number) => any;
    readonly moqtclient_sendPublishNamespaceDone: (a: number, b: number, c: number) => any;
    readonly moqtclient_sendPublishNamespaceError: (a: number, b: bigint, c: bigint, d: number, e: number) => any;
    readonly moqtclient_sendPublishNamespaceOk: (a: number, b: bigint) => any;
    readonly moqtclient_sendPublishOk: (a: number, b: bigint, c: number, d: number, e: number, f: number, g: bigint, h: number, i: bigint, j: number, k: bigint, l: number, m: bigint, n: number) => any;
    readonly moqtclient_sendRelativeJoiningFetch: (a: number, b: bigint, c: bigint, d: bigint, e: number) => any;
    readonly moqtclient_sendRequestsBlocked: (a: number, b: bigint) => any;
    readonly moqtclient_sendSubgroupHeader: (a: number, b: bigint, c: bigint, d: bigint, e: number) => any;
    readonly moqtclient_sendSubgroupObject: (a: number, b: bigint, c: bigint, d: bigint, e: bigint, f: number, g: number, h: number, i: any) => any;
    readonly moqtclient_sendSubscribe: (a: number, b: bigint, c: number, d: number, e: number, f: number, g: number, h: number, i: number, j: number, k: bigint, l: number, m: bigint, n: number, o: bigint, p: number, q: number, r: number, s: number, t: bigint) => any;
    readonly moqtclient_sendSubscribeError: (a: number, b: bigint, c: bigint, d: number, e: number) => any;
    readonly moqtclient_sendSubscribeForward: (a: number, b: bigint, c: bigint, d: number) => any;
    readonly moqtclient_sendSubscribeNamespace: (a: number, b: bigint, c: number, d: number, e: number, f: number) => any;
    readonly moqtclient_sendSubscribeOk: (a: number, b: bigint, c: bigint, d: number, e: bigint, f: number, g: bigint) => any;
    readonly moqtclient_sendSubscribeUpdate: (a: number, b: bigint, c: bigint, d: bigint, e: bigint, f: bigint, g: number, h: number) => any;
    readonly moqtclient_sendTrackStatus: (a: number, b: bigint, c: number, d: number, e: number, f: number, g: number, h: number) => any;
    readonly moqtclient_sendTrackStatusError: (a: number, b: bigint, c: bigint, d: number, e: number) => any;
    readonly moqtclient_sendTrackStatusOk: (a: number, b: bigint) => any;
    readonly moqtclient_sendUnsubscribe: (a: number, b: bigint) => any;
    readonly moqtclient_sendUnsubscribeNamespace: (a: number, b: number, c: number) => any;
    readonly moqtclient_start: (a: number) => any;
    readonly moqtclient_url: (a: number) => any;
    readonly msf_catalog_to_json: (a: any) => [number, number, number, number];
    readonly parse_msf_catalog_json: (a: number, b: number) => [number, number, number];
    readonly __wbg_get_mp4audiotrack_audioSpecificConfig: (a: number) => [number, number];
    readonly __wbg_get_mp4audiotrack_channels: (a: number) => number;
    readonly __wbg_get_mp4audiotrack_codec: (a: number) => [number, number];
    readonly __wbg_get_mp4audiotrack_sampleRate: (a: number) => number;
    readonly __wbg_get_mp4sampletable_dtsMicros: (a: number) => [number, number];
    readonly __wbg_get_mp4sampletable_kind: (a: number) => [number, number];
    readonly __wbg_get_mp4sampletable_offset: (a: number) => [number, number];
    readonly __wbg_get_mp4sampletable_ptsMicros: (a: number) => [number, number];
    readonly __wbg_get_mp4sampletable_size: (a: number) => [number, number];
    readonly __wbg_get_mp4sampletable_sync: (a: number) => [number, number];
    readonly __wbg_get_mp4videotrack_height: (a: number) => number;
    readonly __wbg_get_mp4videotrack_width: (a: number) => number;
    readonly __wbg_mp4audiotrack_free: (a: number, b: number) => void;
    readonly __wbg_mp4index_free: (a: number, b: number) => void;
    readonly __wbg_mp4sampletable_free: (a: number, b: number) => void;
    readonly __wbg_mp4videotrack_free: (a: number, b: number) => void;
    readonly __wbg_set_mp4audiotrack_audioSpecificConfig: (a: number, b: number, c: number) => void;
    readonly __wbg_set_mp4audiotrack_channels: (a: number, b: number) => void;
    readonly __wbg_set_mp4audiotrack_codec: (a: number, b: number, c: number) => void;
    readonly __wbg_set_mp4audiotrack_sampleRate: (a: number, b: number) => void;
    readonly __wbg_set_mp4sampletable_dtsMicros: (a: number, b: number, c: number) => void;
    readonly __wbg_set_mp4sampletable_kind: (a: number, b: number, c: number) => void;
    readonly __wbg_set_mp4sampletable_offset: (a: number, b: number, c: number) => void;
    readonly __wbg_set_mp4sampletable_ptsMicros: (a: number, b: number, c: number) => void;
    readonly __wbg_set_mp4sampletable_size: (a: number, b: number, c: number) => void;
    readonly __wbg_set_mp4sampletable_sync: (a: number, b: number, c: number) => void;
    readonly __wbg_set_mp4videotrack_height: (a: number, b: number) => void;
    readonly __wbg_set_mp4videotrack_width: (a: number, b: number) => void;
    readonly __wbg_subgroupstate_free: (a: number, b: number) => void;
    readonly mp4index_annexBVideoSample: (a: number, b: number, c: number, d: number) => [number, number, number, number];
    readonly mp4index_audio: (a: number) => number;
    readonly mp4index_durationMicros: (a: number) => number;
    readonly mp4index_new: (a: number, b: number) => [number, number, number];
    readonly mp4index_reorderDelayMicros: (a: number) => number;
    readonly mp4index_samples: (a: number) => number;
    readonly mp4index_video: (a: number) => [number, number, number];
    readonly subgroupstate_groupId: (a: number) => bigint;
    readonly subgroupstate_headerSent: (a: number) => number;
    readonly subgroupstate_objectId: (a: number) => bigint;
    readonly subgroupstate_subgroupId: (a: number) => bigint;
    readonly subgroupstate_trackAlias: (a: number) => bigint;
    readonly __wbg_set_mp4videotrack_codec: (a: number, b: number, c: number) => void;
    readonly __wbg_get_mp4videotrack_codec: (a: number) => [number, number];
    readonly wasm_bindgen__convert__closures_____invoke__h5b3fa9a4add80240: (a: number, b: number, c: any) => [number, number];
    readonly wasm_bindgen__convert__closures_____invoke__h4a33fe58a4250870: (a: number, b: number, c: any) => [number, number];
    readonly wasm_bindgen__convert__closures_____invoke__h4a33fe58a4250870_2: (a: number, b: number, c: any) => [number, number];
    readonly wasm_bindgen__convert__closures_____invoke__h4a33fe58a4250870_3: (a: number, b: number, c: any) => [number, number];
    readonly wasm_bindgen__convert__closures_____invoke__h13298db01f47669e: (a: number, b: number, c: any, d: any) => void;
    readonly __wbindgen_malloc: (a: number, b: number) => number;
    readonly __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
    readonly __wbindgen_exn_store: (a: number) => void;
    readonly __externref_table_alloc: () => number;
    readonly __wbindgen_externrefs: WebAssembly.Table;
    readonly __wbindgen_free: (a: number, b: number, c: number) => void;
    readonly __wbindgen_destroy_closure: (a: number, b: number) => void;
    readonly __externref_table_dealloc: (a: number) => void;
    readonly __externref_drop_slice: (a: number, b: number) => void;
    readonly __wbindgen_start: () => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;

/**
 * Instantiates the given `module`, which can either be bytes or
 * a precompiled `WebAssembly.Module`.
 *
 * @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
 *
 * @returns {InitOutput}
 */
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
 * If `module_or_path` is {RequestInfo} or {URL}, makes a request and
 * for everything else, calls `WebAssembly.instantiate` directly.
 *
 * @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
 *
 * @returns {Promise<InitOutput>}
 */
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;
